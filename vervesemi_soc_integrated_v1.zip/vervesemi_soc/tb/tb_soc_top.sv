// ============================================================================
// tb_soc_top.sv -- full-SoC integration testbench (run with Verilator >= 5).
// ----------------------------------------------------------------------------
// Requires the bsc-generated Verilog (make bsv-verilog) in bsv/verilog/.
//
//   1. loads fw/soc_demo.hex into the BRAM through the TB backdoor
//   2. lets the RV32IM core run the demo firmware, which drives the whole
//      MMIO path: splitter -> NoC -> UART / NVIC / soc_ctrl / scratch periph
//   3. decodes the UART TX line and checks the transmitted byte ('V')
//   4. checks the firmware's result table via peekWord
//   5. demonstrates the JTAG debugger: DMI HALT -> check halted -> RESUME
//
//   make sim          (see Makefile; roughly:
//    verilator --binary --timing -sv --top-module tb_soc_top \
//      tb/tb_soc_top.sv rtl/integration/*.sv rtl/integration/*.v \
//      rtl/noc/*.sv rtl/nvic/*.v rtl/uart/<all but uart_top.v> \
//      rtl/debug/jtag_tap.v rtl/debug/jtag_register.v bsv/verilog/*.v)
// ============================================================================
`timescale 1ns/1ps

module tb_soc_top;

  // ---- clocks & resets ----
  logic clk = 0, tck = 0;
  logic rst_n = 0, trst_n = 0;
  always #5  clk = ~clk;    // 100 MHz CPU/NoC clock
  always #40 tck = ~tck;    // 12.5 MHz JTAG/debug clock

  // ---- DUT ----
  logic tms = 1, tdi = 0, tdo;
  logic uart_line;                        // TX looped back to RX
  logic irq_out;
  logic [6:0] irq_id_out;
  logic [31:0] tb_init_idx = 0, tb_init_data = 0, tb_peek_idx = 0;
  logic tb_init_en = 0;
  logic tb_init_rdy;
  logic [31:0] tb_peek_data;
  logic tb_retired, tb_core_halted;

  soc_top dut (
    .clk(clk), .rst_n(rst_n),
    .tck(tck), .tms(tms), .tdi(tdi), .trst_n(trst_n), .tdo(tdo),
    .uart_rx(uart_line), .uart_tx(uart_line),      // external loopback jumper
    .ext_irq(16'h0),
    .irq_out(irq_out), .irq_id_out(irq_id_out),
    .tb_init_idx(tb_init_idx), .tb_init_data(tb_init_data),
    .tb_init_en(tb_init_en), .tb_init_rdy(tb_init_rdy),
    .tb_peek_idx(tb_peek_idx), .tb_peek_data(tb_peek_data),
    .tb_retired(tb_retired), .tb_core_halted(tb_core_halted)
  );

  // ---- scoreboard ----
  int fails = 0;
  task check(string what, logic [31:0] got, logic [31:0] exp);
    if (got !== exp) begin
      $display("FAIL: %s got=0x%08h exp=0x%08h", what, got, exp);
      fails++;
    end else
      $display("  ok: %s = 0x%08h", what, got);
  endtask

  // ---- UART TX-line monitor (8N1, DLL=1 & 16x oversample -> 16 clk/bit) ----
  localparam int BITCYC = 16;
  byte uart_seen [$];
  initial begin : uart_mon
    logic [7:0] b;
    forever begin
      @(negedge uart_line);                       // start bit
      if (!rst_n) continue;
      repeat (BITCYC + BITCYC/2) @(posedge clk);  // to middle of bit 0
      for (int i = 0; i < 8; i++) begin
        b[i] = uart_line;
        repeat (BITCYC) @(posedge clk);
      end
      $display("  [uart-mon] TX byte 0x%02h ('%c')", b, b);
      uart_seen.push_back(b);
    end
  end

  // ---- memory backdoor helpers ----
  logic [31:0] prog [0:1023];

  task load_program;
    int n;
    for (n = 0; n < 1024; n++) prog[n] = 32'h0;
    $readmemh("fw/soc_demo.hex", prog);
    for (int i = 0; i < 1024; i++) begin
      @(posedge clk);
      while (!tb_init_rdy) @(posedge clk);
      tb_init_idx  <= i;
      tb_init_data <= prog[i];
      tb_init_en   <= 1;
      @(posedge clk);
      tb_init_en   <= 0;
    end
    $display("[tb] program loaded (1024 words incl. zero fill)");
  endtask

  function logic [31:0] peek(input logic [31:0] word_idx);
    tb_peek_idx = word_idx;
    return tb_peek_data;   // combinational value method
  endfunction

  // ==========================================================================
  // JTAG driver (mirrors the CXXRTL smoke test, incl. the one-bit TDO lag of
  // the registered-TDO DTM: sample after shift edge i belongs to out bit i-1)
  // ==========================================================================
  task tck_step(input logic tms_i, input logic tdi_i, output logic tdo_o);
    tms = tms_i; tdi = tdi_i;
    @(posedge tck); #1;
    tdo_o = tdo;
  endtask

  task tap_reset;
    logic t;
    repeat (6) tck_step(1, 0, t);
    tck_step(0, 0, t);
  endtask

  task ir_scan(input logic [4:0] ir);
    logic t;
    tck_step(1, 0, t); tck_step(1, 0, t);      // Select-DR, Select-IR
    tck_step(0, 0, t);                         // Capture-IR
    tck_step(0, 0, t);                         // enter Shift-IR
    for (int i = 0; i < 5; i++) tck_step(i == 4, ir[i], t);
    tck_step(1, 0, t); tck_step(0, 0, t);      // Update-IR, RTI
  endtask

  task dr_scan41(input logic [40:0] w, output logic [40:0] out);
    logic t;
    tck_step(1, 0, t);                         // Select-DR
    tck_step(0, 0, t);                         // Capture-DR
    tck_step(0, 0, t);                         // enter Shift-DR
    out = '0;
    for (int i = 0; i < 41; i++) begin
      tck_step(i == 40, w[i], t);
      if (i > 0) out[i-1] = t;                 // registered-TDO one-bit lag
    end
    tck_step(1, 0, t); tck_step(0, 0, t);      // Update-DR, RTI
  endtask

  function logic [40:0] dmi_word(input logic [6:0] a, input logic [31:0] d,
                                 input logic [1:0] op);
    return {a, d, op};
  endfunction

  task dmi_write(input logic [6:0] a, input logic [31:0] d);
    logic [40:0] dummy;
    dr_scan41(dmi_word(a, d, 2'd2), dummy);
  endtask

  task dmi_read(input logic [6:0] a, output logic [31:0] d);
    logic [40:0] o;
    dr_scan41(dmi_word(a, 32'h0, 2'd1), o);    // request the read
    dr_scan41(dmi_word(a, 32'h0, 2'd1), o);    // capture returns it
    d = o[33:2];
  endtask

  // ==========================================================================
  // main sequence
  // ==========================================================================
  initial begin
    if ($test$plusargs("vcd")) begin
      $dumpfile("soc_top.vcd");
      $dumpvars(0, tb_soc_top);
    end

    repeat (10) @(posedge clk);
    rst_n = 1; trst_n = 1;
    repeat (5) @(posedge clk);

    load_program();

    // ---- wait for the firmware to write its result magic ----
    tb_peek_idx = 32'h100;                     // byte 0x400 -> word 0x100
    fork : waiter
      begin
        wait (tb_peek_data == 32'hC0DEC0DE || tb_peek_data[31:20] == 12'hBAD);
        disable waiter;
      end
      begin
        repeat (600_000) @(posedge clk);
        $display("FAIL: watchdog timeout waiting for firmware result");
        fails++;
        disable waiter;
      end
    join

    // ---- check the firmware result table ----
    check("result magic       ", peek(32'h100), 32'hC0DEC0DE);
    check("first irq id  (sw) ", peek(32'h101), 32'd24);
    check("uart rx byte       ", peek(32'h102), 32'h56);
    check("second irq id (rx) ", peek(32'h103), 32'd16);
    check("SOC_ID             ", peek(32'h104), 32'h5EC02026);
    check("scratch periph ID  ", peek(32'h105), 32'hA5A50003);
    check("scratch readback   ", peek(32'h106), 32'h015A5234);
    if (uart_seen.size() > 0)
      check("uart TX line byte  ", {24'h0, uart_seen[0]}, 32'h56);
    else begin
      $display("FAIL: no byte observed on the UART TX line");
      fails++;
    end

    // ---- JTAG debugger demo: HALT the core, verify, RESUME ----
    $display("[tb] JTAG: halting the core over DMI...");
    tap_reset();
    ir_scan(5'h11);                            // select DMI
    dmi_write(7'h12, 32'h1);                   // EXEC cmd=1 (DBG_HALT)
    repeat (30) @(posedge tck);                // CDC + pipeline drain
    begin
      logic [31:0] st;
      dmi_read(7'h14, st);                     // STATUS
      check("jtag: core halted  ", {31'h0, st[1]}, 32'h1);
      check("jtag: halted pin   ", {31'h0, tb_core_halted}, 32'h1);
      dmi_write(7'h12, 32'h2);                 // EXEC cmd=2 (DBG_RESUME)
      repeat (30) @(posedge tck);
      dmi_read(7'h14, st);
      check("jtag: core resumed ", {31'h0, st[1]}, 32'h0);
    end

    if (fails == 0) $display("=== TB PASS: integrated SoC works end-to-end ===");
    else            $display("=== TB FAIL: %0d check(s) failed ===", fails);
    $finish;
  end

endmodule

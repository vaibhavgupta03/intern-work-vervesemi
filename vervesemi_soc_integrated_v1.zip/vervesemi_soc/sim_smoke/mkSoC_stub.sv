// ============================================================================
// mkSoC_stub.sv -- port-contract stub of the bsc-generated mkSoC.
// ----------------------------------------------------------------------------
// Used ONLY for elaboration/lint (scripts/elab_check.py) before bsc has been
// run, so that soc_top.sv's wiring can be type-checked end-to-end. It encodes
// the port list we expect bsc to emit for bsv/top/SoC.bsv. After running
// `make bsv-verilog`, diff this port list against bsv/verilog/mkSoC.v and fix
// any naming differences (then use the real mkSoC.v, never this stub, for
// simulation).
// ============================================================================
`default_nettype none

module mkSoC (
  input  wire        CLK,
  input  wire        RST_N,
  input  wire        CLK_dClk,
  input  wire        RST_N_dRst,

  // interface AXI4Lite_Master mmio
  output wire [34:0] mmio_aw_get,     // {awaddr[31:0], awprot[2:0]}
  output wire        RDY_mmio_aw_get,
  input  wire        EN_mmio_aw_get,
  output wire [35:0] mmio_w_get,      // {wdata[31:0], wstrb[3:0]}
  output wire        RDY_mmio_w_get,
  input  wire        EN_mmio_w_get,
  input  wire [1:0]  mmio_b_put,      // bresp
  output wire        RDY_mmio_b_put,
  input  wire        EN_mmio_b_put,
  output wire [34:0] mmio_ar_get,     // {araddr[31:0], arprot[2:0]}
  output wire        RDY_mmio_ar_get,
  input  wire        EN_mmio_ar_get,
  input  wire [33:0] mmio_r_put,      // {rdata[31:0], rresp[1:0]}
  output wire        RDY_mmio_r_put,
  input  wire        EN_mmio_r_put,

  // interface DbgHostIfc debug (CLK_dClk domain)
  input  wire [71:0] debug_enqReq_r,  // {cmd[2:0], regno[4:0], addr[31:0], wdata[31:0]}
  input  wire        EN_debug_enqReq,
  output wire        RDY_debug_enqReq,
  output wire [32:0] debug_getResp,   // {halted, rdata[31:0]}
  input  wire        EN_debug_getResp,
  output wire        RDY_debug_getResp,
  output wire        debug_respAvail,
  output wire        RDY_debug_respAvail,
  output wire        debug_coreHalted,
  output wire        RDY_debug_coreHalted,

  // TB backdoor + retire monitor
  input  wire [31:0] initWord_wordIdx,
  input  wire [31:0] initWord_v,
  input  wire        EN_initWord,
  output wire        RDY_initWord,
  input  wire [31:0] peekWord_wordIdx,
  output wire [31:0] peekWord,
  output wire        RDY_peekWord,
  output wire        retired
);

  // lint stub: benign constant drivers
  assign mmio_aw_get = 35'h0;  assign RDY_mmio_aw_get = 1'b0;
  assign mmio_w_get  = 36'h0;  assign RDY_mmio_w_get  = 1'b0;
  assign RDY_mmio_b_put = 1'b1;
  assign mmio_ar_get = 35'h0;  assign RDY_mmio_ar_get = 1'b0;
  assign RDY_mmio_r_put = 1'b1;
  assign RDY_debug_enqReq  = 1'b1;
  assign debug_getResp = 33'h0;  assign RDY_debug_getResp = 1'b0;
  assign debug_respAvail = 1'b0; assign RDY_debug_respAvail = 1'b1;
  assign debug_coreHalted = 1'b0; assign RDY_debug_coreHalted = 1'b1;
  assign RDY_initWord = 1'b1;
  assign peekWord = 32'h0;  assign RDY_peekWord = 1'b1;
  assign retired = 1'b0;

endmodule

`default_nettype wire

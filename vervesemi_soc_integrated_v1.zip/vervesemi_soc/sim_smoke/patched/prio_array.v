// SIM-ONLY copy of rtl/nvic/prio_array.v with the unpacked-array read port
// flattened to a single packed bus (yosys read_verilog compatibility).
module prio_array #(
    parameter NUM_SOURCES  = 128,
    parameter PRIO_WIDTH   = 8
)(
    input  wire                              clk,
    input  wire                              rst,
    input  wire                              wr_en,
    input  wire [$clog2(NUM_SOURCES)-1:0]    wr_idx,
    input  wire [PRIO_WIDTH-1:0]             wr_data,
    input  wire [PRIO_WIDTH-1:0]             prio_mask,
    output wire [PRIO_WIDTH*NUM_SOURCES-1:0] prio_out
);
    reg [PRIO_WIDTH-1:0] mem [0:NUM_SOURCES-1];
    integer i;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (i = 0; i < NUM_SOURCES; i = i + 1)
                mem[i] <= 8'hFF;
        end
        else if (wr_en) begin
            mem[wr_idx] <= wr_data & prio_mask;
        end
    end
    genvar g;
    generate
      for (g = 0; g < NUM_SOURCES; g = g + 1) begin : g_flat
        assign prio_out[g*PRIO_WIDTH +: PRIO_WIDTH] = mem[g];
      end
    endgenerate
endmodule

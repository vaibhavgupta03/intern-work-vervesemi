// SIM-ONLY copy of rtl/nvic/priority_encoder.v with the unpacked-array input
// flattened to a single packed bus (yosys read_verilog compatibility).
module priority_encoder #(
    parameter NUM_SOURCES = 128,
    parameter PRIO_WIDTH  = 8
)(
    input  wire [NUM_SOURCES-1:0]             active,
    input  wire [PRIO_WIDTH*NUM_SOURCES-1:0]  prio_in,
    input  wire [PRIO_WIDTH-1:0]              prio_mask,
    output reg  [$clog2(NUM_SOURCES)-1:0]     winner_id,
    output reg  [PRIO_WIDTH-1:0]              winner_prio,
    output reg                                irq_pending
);
    integer i;
    reg [PRIO_WIDTH-1:0] best_prio;
    reg [$clog2(NUM_SOURCES)-1:0] best_id;
    reg found;
    reg [PRIO_WIDTH-1:0] cur;

    always @(*) begin
        best_prio  = 8'hFF;
        best_id    = 0;
        found      = 1'b0;
        cur        = 8'h00;
        for (i = 0; i < NUM_SOURCES; i = i + 1) begin
            cur = prio_in[i*PRIO_WIDTH +: PRIO_WIDTH];
            if (active[i]) begin
                if (!found || (cur & prio_mask) < (best_prio & prio_mask)) begin
                    best_prio = cur;
                    best_id   = i[$clog2(NUM_SOURCES)-1:0];
                    found     = 1'b1;
                end
            end
        end
        winner_id    = best_id;
        winner_prio  = best_prio & prio_mask;
        irq_pending  = found;
    end
endmodule

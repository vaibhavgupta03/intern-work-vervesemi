// ============================================================================
// tb_periph.cc -- CXXRTL smoke test for the SoC peripheral subsystem
// (UART + NVIC + bridges + soc_ctrl exactly as wired in soc_top.sv).
// The testbench plays the role of the CPU/NoC on three AXI4-Lite ports.
//
// Build (see run_smoke.sh):
//   yowasp-yosys -p "read_verilog -sv <files>; hierarchy -top periph_smoke;
//                    write_cxxrtl build/periph_smoke.cc"
//   g++ -O1 -std=c++17 -I <cxxrtl runtime> tb_periph.cc -o build/tb_periph
// ============================================================================
#include <cstdio>
#include <cstdint>
#include "periph_smoke.h"    // generated CXXRTL model (header mode)

using namespace cxxrtl_design;

static p_periph__smoke top;
static uint64_t cycles = 0;

static void tick() {
  top.p_clk.set<bool>(false); top.step();
  top.p_clk.set<bool>(true);  top.step();
  ++cycles;
}

static int failures = 0;
#define CHECK(cond, msg) do { \
  if (cond) printf("  PASS: %s\n", msg); \
  else      { printf("  FAIL: %s\n", msg); ++failures; } \
} while (0)

// ---- AXI4-Lite BFM, one set of helpers per port prefix -------------------
#define DEF_AXI(P) \
static void axi_write_##P(uint32_t addr, uint32_t data) { \
  top.p_##P##__awaddr.set<uint32_t>(addr & 0xff); \
  top.p_##P##__awvalid.set<bool>(true); \
  top.p_##P##__wdata.set<uint32_t>(data); \
  top.p_##P##__wstrb.set<uint32_t>(0xF); \
  top.p_##P##__wvalid.set<bool>(true); \
  top.p_##P##__bready.set<bool>(true); \
  for (int i = 0; i < 200; i++) { \
    bool aw_hs = top.p_##P##__awvalid.get<bool>() && top.p_##P##__awready.get<bool>(); \
    bool w_hs  = top.p_##P##__wvalid.get<bool>()  && top.p_##P##__wready.get<bool>(); \
    tick(); \
    if (aw_hs) top.p_##P##__awvalid.set<bool>(false); \
    if (w_hs)  top.p_##P##__wvalid.set<bool>(false); \
    if (!top.p_##P##__awvalid.get<bool>() && !top.p_##P##__wvalid.get<bool>()) break; \
  } \
  for (int i = 0; i < 200 && !top.p_##P##__bvalid.get<bool>(); i++) tick(); \
  tick(); /* consume B */ \
  top.p_##P##__bready.set<bool>(false); \
} \
static uint32_t axi_read_##P(uint32_t addr) { \
  top.p_##P##__araddr.set<uint32_t>(addr & 0xff); \
  top.p_##P##__arvalid.set<bool>(true); \
  top.p_##P##__rready.set<bool>(true); \
  for (int i = 0; i < 200; i++) { \
    bool ar_hs = top.p_##P##__arvalid.get<bool>() && top.p_##P##__arready.get<bool>(); \
    tick(); \
    if (ar_hs) { top.p_##P##__arvalid.set<bool>(false); break; } \
  } \
  uint32_t data = 0; \
  for (int i = 0; i < 200; i++) { \
    if (top.p_##P##__rvalid.get<bool>()) { data = top.p_##P##__rdata.get<uint32_t>(); tick(); break; } \
    tick(); \
  } \
  top.p_##P##__rready.set<bool>(false); \
  return data; \
}

DEF_AXI(u)   // UART
DEF_AXI(n)   // NVIC bridge
DEF_AXI(c)   // SOC_CTRL

int main() {
  printf("=== periph_smoke: UART + NVIC + SOC_CTRL integration smoke test ===\n");

  // ---- reset ----
  top.p_rst.set<bool>(true);
  top.p_ext__irq.set<uint32_t>(0);
  for (int i = 0; i < 10; i++) tick();
  top.p_rst.set<bool>(false);
  for (int i = 0; i < 10; i++) tick();

  // ---- 1. SOC_CTRL identification ----
  uint32_t id = axi_read_c(0x00);
  printf("[1] SOC_ID = 0x%08X\n", id);
  CHECK(id == 0x5EC02026u, "SOC_ID reads 0x5EC02026");

  // ---- 2. UART config + TX 'A' with TX->RX loopback ----
  //     LCR: bit9=DLAB, [2:0]=word len (011 = 8 bit)
  axi_write_u(0x06, 0x0200 | 0x3);   // DLAB=1
  axi_write_u(0x00, 0x0001);         // DLL = 1 (divider 1 -> fastest)
  axi_write_u(0x02, 0x0000);         // DLH = 0
  axi_write_u(0x0E, 0x0000);         // DLF = 0
  axi_write_u(0x06, 0x0003);         // DLAB=0, 8-bit word, 1 stop, no parity
  axi_write_u(0x12, 0x0000);         // CLK: os_sel=00 -> 16x oversample

  // NOTE: the baud generator's 16-bit counter free-runs from reset with the
  // divider at 0, so the first oversample tick only appears after the counter
  // wraps (65536 cycles). Real firmware sets the divisor once at boot and
  // never notices; the testbench just waits out the wrap.
  for (int i = 0; i < 70000; i++) tick();

  axi_write_u(0x00, 0x0041);         // THR = 'A' -> tx_start

  // wait for the byte to cross the loopback (frame ~ 16*10 cycles + margins)
  uint32_t rx = 0, rxcnt = 0;
  for (int i = 0; i < 400; i++) {
    for (int k = 0; k < 20; k++) tick();
    rxcnt = axi_read_c(0x08);        // RX_COUNT
    if (rxcnt != 0) break;
  }
  rx = axi_read_c(0x04);             // RX_DATA = {fresh, data[8:0]}
  printf("[2] RX_COUNT=%u RX_DATA=0x%03X (fresh=%u) after %llu cycles\n",
         rxcnt, rx & 0x1ff, (rx >> 9) & 1, (unsigned long long)cycles);
  CHECK(rxcnt == 1, "one byte received via TX->RX loopback");
  CHECK((rx & 0x1ff) == 0x41, "received byte is 'A' (0x41)");
  CHECK(((rx >> 9) & 1) == 1, "RX_DATA fresh flag set");
  uint32_t rx2 = axi_read_c(0x04);
  CHECK(((rx2 >> 9) & 1) == 0, "fresh flag clears on read");

  // ---- 3. NVIC: rx pulse already latched in pend_array (irq 16) ----
  //     enable irq16 (uart rx) and irq24 (sw-triggered), prio 9 and 5
  axi_write_n(0x50, 9);                       // PRIO[16] @ 0x40+16
  axi_write_n(0x58, 5);                       // PRIO[24] @ 0x40+24
  axi_write_n(0x00, (1u<<16) | (1u<<24));     // ENABLE_SET_0
  for (int i = 0; i < 5; i++) tick();

  uint32_t st = axi_read_n(0x38);             // {prio[15:8], pending[7], id[6:0]}
  printf("[3] IRQSTAT after enable = 0x%08X (pend=%u id=%u prio=%u)\n",
         st, (st>>7)&1, st&0x7f, (st>>8)&0xff);
  CHECK(((st>>7)&1) == 1, "irq pending after enable (uart-rx irq16 latched)");
  CHECK((st&0x7f) == 16,  "winner is irq16");

  // ---- 4. software-triggered irq24 (higher priority, lower value) wins ----
  axi_write_c(0x0C, 0x01);                    // SWIRQ bit0 -> irq_in[24]
  for (int i = 0; i < 5; i++) tick();
  st = axi_read_n(0x38);
  printf("[4] IRQSTAT after SWIRQ  = 0x%08X (pend=%u id=%u prio=%u)\n",
         st, (st>>7)&1, st&0x7f, (st>>8)&0xff);
  CHECK((st&0x7f) == 24, "higher-priority irq24 preempts as winner");

  // ---- 5. claim/complete protocol: 24 first, then 16 ----
  axi_write_n(0x30, 0);                       // CLAIM (id 24)
  for (int i = 0; i < 5; i++) tick();
  axi_write_n(0x34, 24);                      // COMPLETE id 24
  for (int i = 0; i < 5; i++) tick();
  st = axi_read_n(0x38);
  printf("[5] IRQSTAT after 24 done= 0x%08X (pend=%u id=%u)\n", st, (st>>7)&1, st&0x7f);
  CHECK(((st>>7)&1) == 1 && (st&0x7f) == 16, "irq16 delivered after irq24 completes");

  axi_write_n(0x30, 0);                       // CLAIM (id 16)
  for (int i = 0; i < 5; i++) tick();
  axi_write_n(0x34, 16);                      // COMPLETE id 16
  for (int i = 0; i < 8; i++) tick();
  st = axi_read_n(0x38);
  printf("[5] IRQSTAT all done     = 0x%08X (pend=%u)\n", st, (st>>7)&1);
  CHECK(((st>>7)&1) == 0, "no interrupt pending after both completed");

  // ---- 6. NVIC regfile readback via the bridge ----
  uint32_t en = axi_read_n(0x00);
  CHECK(en == ((1u<<16)|(1u<<24)), "ENABLE_SET_0 readback via AXI bridge");

  printf("=== %s (%d failure%s, %llu cycles) ===\n",
         failures ? "SMOKE TEST FAILED" : "SMOKE TEST PASSED",
         failures, failures == 1 ? "" : "s", (unsigned long long)cycles);
  return failures ? 1 : 0;
}

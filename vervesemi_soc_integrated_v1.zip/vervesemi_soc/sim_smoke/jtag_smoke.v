// ============================================================================
// jtag_smoke.v -- smoke-test top for the JTAG debug transport (SIM ONLY).
// TAP + IR/IDCODE registers + DMI DTM + debug-module bridge, wired exactly as
// in soc_top.sv. The mkSoC debug-host side (EN/RDY) is exposed so the C++
// testbench can play the role of the Bluespec debug module.
// ============================================================================
`default_nettype none

module jtag_smoke (
    input  wire        tck,
    input  wire        tms,
    input  wire        tdi,
    input  wire        trst_n,
    output wire        tdo,

    // ---- debug-host side (TB plays mkSoC) ----
    output wire [71:0] dbg_req,
    output wire        dbg_req_en,
    input  wire        dbg_req_rdy,
    input  wire [32:0] dbg_resp,
    input  wire        dbg_resp_rdy,
    output wire        dbg_resp_en,
    input  wire        core_halted,

    // observability
    output wire [4:0]  ir_out_o,
    output wire [3:0]  tap_state_o
);

    wire shift_ir, update_ir, shift_dr, update_dr;
    wire [3:0] tap_state;
    wire [4:0] ir_out;
    wire tdo_regs, tdo_dmi;

    localparam [3:0] TAP_CAPTURE_DR = 4'h6;
    wire capture_dr = (tap_state == TAP_CAPTURE_DR);

    assign ir_out_o    = ir_out;
    assign tap_state_o = tap_state;

    jtag_tap u_tap (
        .tck(tck), .tms(tms), .trst_n(trst_n),
        .shift_ir(shift_ir), .update_ir(update_ir),
        .shift_dr(shift_dr), .update_dr(update_dr),
        .tap_state(tap_state)
    );

    jtag_registers u_regs (
        .tck(tck), .trst_n(trst_n), .tdi(tdi),
        .shift_ir(shift_ir), .update_ir(update_ir), .shift_dr(shift_dr),
        .tdo(tdo_regs), .ir_out(ir_out)
    );

    wire        dmi_req_valid;
    wire [6:0]  dmi_req_addr;
    wire [31:0] dmi_req_data;
    wire [1:0]  dmi_req_op;
    wire [31:0] dmi_rsp_data;
    wire [1:0]  dmi_rsp_status;

    dtm_dmi_rv u_dtm (
        .tck(tck), .trst_n(trst_n), .tdi(tdi),
        .shift_dr(shift_dr), .capture_dr(capture_dr), .update_dr(update_dr),
        .ir_out(ir_out),
        .tdo(tdo_dmi),
        .dmi_req_valid(dmi_req_valid), .dmi_req_addr(dmi_req_addr),
        .dmi_req_data(dmi_req_data), .dmi_req_op(dmi_req_op),
        .dmi_rsp_data(dmi_rsp_data), .dmi_rsp_status(dmi_rsp_status)
    );

    jtag_dm_bridge u_br (
        .tck(tck), .trst_n(trst_n),
        .dmi_req_valid(dmi_req_valid), .dmi_req_addr(dmi_req_addr),
        .dmi_req_data(dmi_req_data), .dmi_req_op(dmi_req_op),
        .dmi_rsp_data(dmi_rsp_data), .dmi_rsp_status(dmi_rsp_status),
        .dbg_req(dbg_req), .dbg_req_en(dbg_req_en), .dbg_req_rdy(dbg_req_rdy),
        .dbg_resp(dbg_resp), .dbg_resp_rdy(dbg_resp_rdy), .dbg_resp_en(dbg_resp_en),
        .core_halted(core_halted)
    );

    assign tdo = (ir_out == 5'h11) ? tdo_dmi : tdo_regs;

endmodule

`default_nettype wire

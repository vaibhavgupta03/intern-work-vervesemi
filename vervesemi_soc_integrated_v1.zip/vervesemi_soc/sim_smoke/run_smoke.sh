#!/usr/bin/env bash
# ============================================================================
# run_smoke.sh -- build + run both smoke tests with yosys CXXRTL.
# Works without bsc or Verilator (pip install yowasp-yosys is enough):
#   test 1: periph_smoke = UART + NVIC(+bridge) + soc_ctrl, AXI BFM as CPU
#   test 2: jtag_smoke   = TAP + DTM(DMI) + debug-module bridge
# Note: the NVIC in test 1 is built at NUM_SOURCES=32 (patched sim copies) so
# the CXXRTL model stays small; soc_top.sv instantiates the full 128 sources.
# ============================================================================
set -e
cd "$(dirname "$0")/.."

YOSYS=${YOSYS:-$(command -v yosys || command -v yowasp-yosys)}
[ -z "$YOSYS" ] && { echo "need yosys (pip install yowasp-yosys)"; exit 1; }

CXXRTL_INC=${CXXRTL_INC:-$("$YOSYS" --version >/dev/null 2>&1 && \
  python3 -c "import yowasp_yosys,os;print(os.path.join(os.path.dirname(yowasp_yosys.__file__),'share/include/backends/cxxrtl/runtime'))" 2>/dev/null || \
  yosys-config --datdir)/include/backends/cxxrtl/runtime}

mkdir -p sim_smoke/build

echo "=== [1/2] peripheral subsystem smoke test ==="
"$YOSYS" -q -p "
read_verilog -sv sim_smoke/patched/prio_array.v sim_smoke/patched/priority_encoder.v \
  sim_smoke/patched/nvic_top.v sim_smoke/patched/vic_regfile.v \
  rtl/nvic/enable_array.v rtl/nvic/irq_count_decoder.v rtl/nvic/nvic_controller.v \
  rtl/nvic/pend_array.v rtl/nvic/prio_width_decoder.v \
  rtl/uart/axi4lite_slave.v rtl/uart/baudrategenerator.v rtl/uart/generic_register.v \
  rtl/uart/os_sel_decoder.v rtl/uart/parity_decoder.v rtl/uart/stop_bits_decoder.v \
  rtl/uart/uart_receiver.v rtl/uart/uart_regfile.v rtl/uart/uart_transmitter.v \
  rtl/uart/word_len_decoder.v \
  rtl/integration/uart_top_soc.v rtl/integration/axil_nvic_bridge.v rtl/integration/soc_ctrl.v \
  sim_smoke/periph_smoke.v
hierarchy -top periph_smoke
proc; flatten; opt -purge
write_cxxrtl -header -g0 sim_smoke/build/periph_smoke.cc"
g++ -O0 -std=c++17 -w -pipe -I "$CXXRTL_INC" -I sim_smoke/build \
    -c sim_smoke/build/periph_smoke.cc -o sim_smoke/build/periph_smoke.o
g++ -O0 -std=c++17 -w -pipe -I "$CXXRTL_INC" -I sim_smoke/build \
    sim_smoke/tb_periph.cc sim_smoke/build/periph_smoke.o -o sim_smoke/build/tb_periph
sim_smoke/build/tb_periph

echo
echo "=== [2/2] JTAG debug transport smoke test ==="
"$YOSYS" -q -p "
read_verilog -sv rtl/debug/jtag_tap.v rtl/debug/jtag_register.v \
  rtl/integration/dtm_dmi_rv.v rtl/integration/jtag_dm_bridge.v sim_smoke/jtag_smoke.v
hierarchy -top jtag_smoke
proc; flatten; opt -purge
write_cxxrtl -header -g0 sim_smoke/build/jtag_smoke.cc"
g++ -O0 -std=c++17 -w -pipe -I "$CXXRTL_INC" -I sim_smoke/build \
    sim_smoke/tb_jtag.cc sim_smoke/build/jtag_smoke.cc -o sim_smoke/build/tb_jtag
sim_smoke/build/tb_jtag

echo
echo "=== all smoke tests passed ==="

// ============================================================================
// periph_smoke.v -- smoke-test top for the peripheral subsystem (SIM ONLY).
// ----------------------------------------------------------------------------
// Contains exactly the peripheral cluster that hangs off NoC concentrator 0 in
// soc_top.sv (UART + NVIC-bridge + SOC_CTRL, with identical wiring), but with
// the three AXI4-Lite slave ports exported directly so the C++ CXXRTL
// testbench can play the role of the CPU/NoC. UART TX is looped back to RX.
// The NoC itself is excluded here only because the sandbox simulator cannot
// parse SV array ports -- it was already verified to 100% coverage by its
// author with Verilator, and the full path is covered by tb/tb_soc_top.sv.
// ============================================================================
`default_nettype none

module periph_smoke (
    input  wire        clk,
    input  wire        rst,

    // ---- AXI port 0 : UART ----
    input  wire [7:0]  u_awaddr,
    input  wire        u_awvalid,
    output wire        u_awready,
    input  wire [31:0] u_wdata,
    input  wire [3:0]  u_wstrb,
    input  wire        u_wvalid,
    output wire        u_wready,
    output wire [1:0]  u_bresp,
    output wire        u_bvalid,
    input  wire        u_bready,
    input  wire [7:0]  u_araddr,
    input  wire        u_arvalid,
    output wire        u_arready,
    output wire [31:0] u_rdata,
    output wire [1:0]  u_rresp,
    output wire        u_rvalid,
    input  wire        u_rready,

    // ---- AXI port 1 : NVIC bridge ----
    input  wire [7:0]  n_awaddr,
    input  wire        n_awvalid,
    output wire        n_awready,
    input  wire [31:0] n_wdata,
    input  wire [3:0]  n_wstrb,
    input  wire        n_wvalid,
    output wire        n_wready,
    output wire [1:0]  n_bresp,
    output wire        n_bvalid,
    input  wire        n_bready,
    input  wire [7:0]  n_araddr,
    input  wire        n_arvalid,
    output wire        n_arready,
    output wire [31:0] n_rdata,
    output wire [1:0]  n_rresp,
    output wire        n_rvalid,
    input  wire        n_rready,

    // ---- AXI port 2 : SOC_CTRL ----
    input  wire [7:0]  c_awaddr,
    input  wire        c_awvalid,
    output wire        c_awready,
    input  wire [31:0] c_wdata,
    input  wire [3:0]  c_wstrb,
    input  wire        c_wvalid,
    output wire        c_wready,
    output wire [1:0]  c_bresp,
    output wire        c_bvalid,
    input  wire        c_bready,
    input  wire [7:0]  c_araddr,
    input  wire        c_arvalid,
    output wire        c_arready,
    output wire [31:0] c_rdata,
    output wire [1:0]  c_rresp,
    output wire        c_rvalid,
    input  wire        c_rready,

    // ---- observability ----
    input  wire [15:0] ext_irq,
    output wire        irq_out,
    output wire [6:0]  irq_id_out,
    output wire        uart_tx_line
);

    // ---- UART with TX->RX loopback ----
    wire tx_line;
    wire [8:0] rx_data;
    wire rx_valid, tx_busy, tx_done;

    assign uart_tx_line = tx_line;

    uart_top_soc #(
        .AXI_ADDR_WIDTH(8),
        .AXI_DATA_WIDTH(32),
        .CLOCK_FREQUENCY(100_000_000)
    ) u_uart (
        .clk(clk), .rst(rst),
        .rx(tx_line),                 // loopback
        .tx(tx_line),
        .s_awaddr(u_awaddr), .s_awvalid(u_awvalid), .s_awready(u_awready),
        .s_wdata(u_wdata), .s_wstrb(u_wstrb), .s_wvalid(u_wvalid), .s_wready(u_wready),
        .s_bresp(u_bresp), .s_bvalid(u_bvalid), .s_bready(u_bready),
        .s_araddr(u_araddr), .s_arvalid(u_arvalid), .s_arready(u_arready),
        .s_rdata(u_rdata), .s_rresp(u_rresp), .s_rvalid(u_rvalid), .s_rready(u_rready),
        .rx_data_o(rx_data), .rx_valid_o(rx_valid),
        .tx_busy_o(tx_busy), .tx_done_o(tx_done)
    );

    // ---- NVIC + bridge (same wiring as soc_top.sv) ----
    wire        nvic_wr_en;
    wire [7:0]  nvic_addr;
    wire [31:0] nvic_wr_data;
    wire [7:0]  nvic_rd_addr;
    wire [31:0] nvic_rd_data;
    wire        cpu_claim, cpu_complete;
    wire [6:0]  cpu_complete_id;
    wire        irq_to_cpu;
    wire [6:0]  irq_id_to_cpu;
    wire [7:0]  irq_prio_to_cpu;
    wire [7:0]  swirq;

    wire [127:0] nvic_irq_in;
    assign nvic_irq_in[15:0]   = ext_irq;
    assign nvic_irq_in[16]     = rx_valid;
    assign nvic_irq_in[17]     = tx_done;
    assign nvic_irq_in[23:18]  = 6'b0;
    assign nvic_irq_in[31:24]  = swirq;
    assign nvic_irq_in[127:32] = 96'b0;

    assign irq_out    = irq_to_cpu;
    assign irq_id_out = irq_id_to_cpu;

    axil_nvic_bridge u_nvic_br (
        .clk(clk), .rst(rst),
        .s_awaddr(n_awaddr), .s_awprot(3'b0), .s_awvalid(n_awvalid), .s_awready(n_awready),
        .s_wdata(n_wdata), .s_wstrb(n_wstrb), .s_wvalid(n_wvalid), .s_wready(n_wready),
        .s_bresp(n_bresp), .s_bvalid(n_bvalid), .s_bready(n_bready),
        .s_araddr(n_araddr), .s_arprot(3'b0), .s_arvalid(n_arvalid), .s_arready(n_arready),
        .s_rdata(n_rdata), .s_rresp(n_rresp), .s_rvalid(n_rvalid), .s_rready(n_rready),
        .nvic_wr_en(nvic_wr_en), .nvic_addr(nvic_addr), .nvic_wr_data(nvic_wr_data),
        .nvic_rd_addr(nvic_rd_addr), .nvic_rd_data(nvic_rd_data),
        .cpu_claim(cpu_claim), .cpu_complete(cpu_complete), .cpu_complete_id(cpu_complete_id),
        .irq_pending(irq_to_cpu), .irq_id(irq_id_to_cpu), .irq_prio(irq_prio_to_cpu)
    );

    nvic_top #(.NUM_SOURCES(128), .PRIO_WIDTH(8)) u_nvic (
        .clk(clk), .rst(rst),
        .irq_in(nvic_irq_in),
        .cpu_claim(cpu_claim), .cpu_complete(cpu_complete), .cpu_complete_id(cpu_complete_id),
        .wr_en(nvic_wr_en), .addr(nvic_addr), .wr_data(nvic_wr_data),
        .rd_addr(nvic_rd_addr), .rd_data(nvic_rd_data),
        .irq_to_cpu(irq_to_cpu), .irq_id_to_cpu(irq_id_to_cpu), .irq_prio_to_cpu(irq_prio_to_cpu)
    );

    // ---- SOC_CTRL ----
    soc_ctrl u_ctrl (
        .clk(clk), .rst(rst),
        .s_awaddr(c_awaddr), .s_awprot(3'b0), .s_awvalid(c_awvalid), .s_awready(c_awready),
        .s_wdata(c_wdata), .s_wstrb(c_wstrb), .s_wvalid(c_wvalid), .s_wready(c_wready),
        .s_bresp(c_bresp), .s_bvalid(c_bvalid), .s_bready(c_bready),
        .s_araddr(c_araddr), .s_arprot(3'b0), .s_arvalid(c_arvalid), .s_arready(c_arready),
        .s_rdata(c_rdata), .s_rresp(c_rresp), .s_rvalid(c_rvalid), .s_rready(c_rready),
        .uart_rx_data(rx_data), .uart_rx_valid(rx_valid),
        .swirq_out(swirq),
        .irq_pending(irq_to_cpu), .irq_id(irq_id_to_cpu), .irq_prio(irq_prio_to_cpu)
    );

endmodule

`default_nettype wire

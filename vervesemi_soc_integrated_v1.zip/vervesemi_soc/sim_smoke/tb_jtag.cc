// ============================================================================
// tb_jtag.cc -- CXXRTL smoke test for the JTAG debug transport:
// TAP -> DTM(DMI) -> jtag_dm_bridge -> (TB plays the mkSoC debug module).
//
// Proves the full debugger command path of the integrated SoC:
//   host JTAG wiggles -> 41-bit DMI scans -> staged DbgReq (72 bit) with the
//   right fields -> response captured back out over TDO.
// ============================================================================
#include <cstdio>
#include <cstdint>
#include "jtag_smoke.h"    // generated CXXRTL model (header mode)

using namespace cxxrtl_design;

static p_jtag__smoke top;
static int failures = 0;

#define CHECK(cond, msg) do { \
  if (cond) printf("  PASS: %s\n", msg); \
  else      { printf("  FAIL: %s\n", msg); ++failures; } \
} while (0)

// captured DbgReq (TB = debug module)
static bool     got_req = false;
static uint64_t req_hi = 0;   // bits [71:64]
static uint64_t req_lo = 0;   // bits [63:0]

static bool tck_cycle(bool tms, bool tdi) {
  top.p_tms.set<bool>(tms);
  top.p_tdi.set<bool>(tdi);
  top.p_tck.set<bool>(false); top.step();
  top.p_tck.set<bool>(true);  top.step();
  // snoop the debug-request handshake (TB always ready)
  if (top.p_dbg__req__en.get<bool>()) {
    got_req = true;
    // 72-bit value: chunks
    req_lo = (uint64_t)top.p_dbg__req.curr.data[0] | ((uint64_t)top.p_dbg__req.curr.data[1] << 32);
    req_hi = (uint64_t)top.p_dbg__req.curr.data[2] & 0xff;                 // bits [71:64]
  }
  return top.p_tdo.get<bool>();
}

static void tap_reset() {
  for (int i = 0; i < 6; i++) tck_cycle(true, false);   // -> Test-Logic-Reset
  tck_cycle(false, false);                              // -> Run-Test/Idle
}

static void ir_scan(uint32_t ir) {                      // from RTI
  tck_cycle(true, false);   // Select-DR
  tck_cycle(true, false);   // Select-IR
  tck_cycle(false, false);  // Capture-IR
  tck_cycle(false, false);  // enter Shift-IR (this TAP shifts only while IN Shift state)
  for (int i = 0; i < 5; i++)
    tck_cycle(i == 4, (ir >> i) & 1);                   // Shift-IR (exit on last)
  tck_cycle(true, false);   // Update-IR
  tck_cycle(false, false);  // RTI
}

static uint64_t dr_scan41(uint64_t w) {                 // from RTI, returns TDO word
  tck_cycle(true, false);   // Select-DR
  tck_cycle(false, false);  // Capture-DR (dtm_dmi_rv loads the response here)
  tck_cycle(false, false);  // enter Shift-DR
  // NOTE: this DTM registers TDO on posedge TCK, so the shifted-out stream
  // lags the shift count by one bit: the sample taken after shift edge i is
  // captured bit i-1. Bit 40 is never observable, which is harmless because
  // response words always carry 0 in bits [40:34].
  uint64_t out = 0;
  for (int i = 0; i < 41; i++) {
    bool tdo = tck_cycle(i == 40, (w >> i) & 1);        // Shift-DR
    if (i > 0) out |= (uint64_t)tdo << (i - 1);
  }
  tck_cycle(true, false);   // Update-DR
  tck_cycle(false, false);  // RTI
  return out;
}

static uint64_t dmi_word(uint32_t addr, uint32_t data, uint32_t op) {
  return ((uint64_t)(addr & 0x7f) << 34) | ((uint64_t)data << 2) | (op & 3);
}

int main() {
  printf("=== jtag_smoke: TAP -> DMI -> debug-module bridge smoke test ===\n");

  // ---- reset ----
  top.p_trst__n.set<bool>(false);
  top.p_dbg__req__rdy.set<bool>(true);      // TB debug module always ready
  top.p_dbg__resp__rdy.set<bool>(false);
  top.p_core__halted.set<bool>(false);
  for (int i = 0; i < 4; i++) tck_cycle(true, false);
  top.p_trst__n.set<bool>(true);
  tap_reset();

  // ---- 1. select the DMI instruction (0x11) ----
  ir_scan(0x11);
  CHECK(top.p_ir__out__o.get<uint32_t>() == 0x11, "IR loaded with DMI opcode 0x11");

  // ---- 2. stage ADDR / WDATA, then EXECUTE a DBG_MEM_WR (cmd=7) ----
  dr_scan41(dmi_word(0x10, 0x00000040, 2));  // stage ADDR   = 0x40
  dr_scan41(dmi_word(0x11, 0xCAFEF00D, 2));  // stage WDATA  = 0xCAFEF00D
  got_req = false;
  dr_scan41(dmi_word(0x12, (0x00 << 3) | 7, 2)); // EXEC: cmd=7 MEM_WR, regno=0
  tck_cycle(false, false);  // dmi_req_valid registers at Update-DR; the bridge
  tck_cycle(false, false);  // stages + hands the command over on the next edges

  CHECK(got_req, "DbgReq issued to the debug module after EXEC");
  uint32_t cmd   = (uint32_t)(req_hi >> 5) & 0x7;
  uint32_t regno = (uint32_t)(req_hi) & 0x1f;
  uint32_t addr  = (uint32_t)(req_lo >> 32);
  uint32_t wdata = (uint32_t)(req_lo & 0xffffffff);
  printf("[2] DbgReq = cmd=%u regno=%u addr=0x%08X wdata=0x%08X\n", cmd, regno, addr, wdata);
  CHECK(cmd == 7,            "DbgReq.cmd   == DBG_MEM_WR");
  CHECK(regno == 0,          "DbgReq.regno == 0");
  CHECK(addr == 0x40,        "DbgReq.addr  == 0x40");
  CHECK(wdata == 0xCAFEF00D, "DbgReq.wdata == 0xCAFEF00D");

  // ---- 3. TB (as mkSoC) returns a response: halted=1, rdata=0x12345678 ----
  top.p_dbg__resp.set<uint64_t>(((uint64_t)1 << 32) | 0x12345678u); // halted=1
  top.p_dbg__resp__rdy.set<bool>(true);
  tck_cycle(false, false);                   // bridge drains it (auto EN)
  top.p_dbg__resp__rdy.set<bool>(false);
  top.p_core__halted.set<bool>(true);

  // ---- 4. read the response back over DMI ----
  dr_scan41(dmi_word(0x13, 0, 1));           // DMI read of RESP register
  uint64_t out = dr_scan41(dmi_word(0x13, 0, 1)); // capture presents it now
  uint32_t rsp_data = (uint32_t)((out >> 2) & 0xffffffffull);
  uint32_t rsp_stat = (uint32_t)(out & 3);
  printf("[4] DMI readback: data=0x%08X status=%u\n", rsp_data, rsp_stat);
  CHECK(rsp_data == 0x12345678u, "response rdata shifts back out over TDO");
  CHECK(rsp_stat == 0,           "DMI status = success");

  // ---- 5. STATUS register: core_halted + resp_fresh visible ----
  dr_scan41(dmi_word(0x14, 0, 1));
  out = dr_scan41(dmi_word(0x14, 0, 1));
  uint32_t stat = (uint32_t)((out >> 2) & 0xffffffffull);
  printf("[5] STATUS = 0x%08X (resp_cnt=%u halted=%u fresh=%u)\n",
         stat, (stat >> 2) & 0xff, (stat >> 1) & 1, stat & 1);
  CHECK(((stat >> 1) & 1) == 1, "core_halted visible over JTAG");
  CHECK(((stat >> 2) & 0xff) == 1, "one response counted");

  printf("=== %s (%d failure%s) ===\n",
         failures ? "SMOKE TEST FAILED" : "SMOKE TEST PASSED",
         failures, failures == 1 ? "" : "s");
  return failures ? 1 : 0;
}

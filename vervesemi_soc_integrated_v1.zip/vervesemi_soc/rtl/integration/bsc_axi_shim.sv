// ============================================================================
// bsc_axi_shim.sv -- adapts the bsc-generated Get/Put (EN/RDY) ports of the
// mkSoC `mmio` AXI4-Lite master interface to standard AXI4-Lite signals.
// ----------------------------------------------------------------------------
// bsc port-name convention for `interface AXI4Lite_Master mmio` inside SoCIfc:
//   Get#(AxiAW) aw -> output [34:0] mmio_aw_get , output RDY_mmio_aw_get ,
//                     input EN_mmio_aw_get      ({awaddr[31:0], awprot[2:0]})
//   Get#(AxiW)  w  -> output [35:0] mmio_w_get  ({wdata[31:0], wstrb[3:0]})
//   Put#(AxiB)  b  -> input  [1:0]  mmio_b_put  (bresp), EN/RDY
//   Get#(AxiAR) ar -> output [34:0] mmio_ar_get ({araddr[31:0], arprot[2:0]})
//   Put#(AxiR)  r  -> input  [33:0] mmio_r_put  ({rdata[31:0], rresp[1:0]})
//
// Handshake mapping (Get -> AXI source): RDY = valid, EN = valid & ready.
// Handshake mapping (Put -> AXI sink)  : RDY = ready, EN = valid & ready.
// bsc FIFO-backed RDY is stable until dequeued, so AXI's "valid must stay
// asserted until ready" rule is satisfied.
//
// !! After running `make bsv-verilog`, open bsv/verilog/mkSoC.v and confirm
// !! the port names/widths match; adjust here if your bsc version differs.
// ============================================================================
`default_nettype none

module bsc_axi_shim (
  // ---- bsc side (connect straight to mkSoC ports) ----
  input  wire [34:0] mmio_aw_get,
  input  wire        RDY_mmio_aw_get,
  output wire        EN_mmio_aw_get,

  input  wire [35:0] mmio_w_get,
  input  wire        RDY_mmio_w_get,
  output wire        EN_mmio_w_get,

  output wire [1:0]  mmio_b_put,
  input  wire        RDY_mmio_b_put,
  output wire        EN_mmio_b_put,

  input  wire [34:0] mmio_ar_get,
  input  wire        RDY_mmio_ar_get,
  output wire        EN_mmio_ar_get,

  output wire [33:0] mmio_r_put,
  input  wire        RDY_mmio_r_put,
  output wire        EN_mmio_r_put,

  // ---- standard AXI4-Lite master side ----
  output wire [31:0] m_awaddr,
  output wire [2:0]  m_awprot,
  output wire        m_awvalid,
  input  wire        m_awready,

  output wire [31:0] m_wdata,
  output wire [3:0]  m_wstrb,
  output wire        m_wvalid,
  input  wire        m_wready,

  input  wire [1:0]  m_bresp,
  input  wire        m_bvalid,
  output wire        m_bready,

  output wire [31:0] m_araddr,
  output wire [2:0]  m_arprot,
  output wire        m_arvalid,
  input  wire        m_arready,

  input  wire [31:0] m_rdata,
  input  wire [1:0]  m_rresp,
  input  wire        m_rvalid,
  output wire        m_rready
);

  // AW : bsc Get -> AXI source
  assign {m_awaddr, m_awprot} = mmio_aw_get;
  assign m_awvalid            = RDY_mmio_aw_get;
  assign EN_mmio_aw_get       = RDY_mmio_aw_get & m_awready;

  // W
  assign {m_wdata, m_wstrb}   = mmio_w_get;
  assign m_wvalid             = RDY_mmio_w_get;
  assign EN_mmio_w_get        = RDY_mmio_w_get & m_wready;

  // B : AXI sink -> bsc Put
  assign mmio_b_put           = m_bresp;
  assign m_bready             = RDY_mmio_b_put;
  assign EN_mmio_b_put        = m_bvalid & RDY_mmio_b_put;

  // AR
  assign {m_araddr, m_arprot} = mmio_ar_get;
  assign m_arvalid            = RDY_mmio_ar_get;
  assign EN_mmio_ar_get       = RDY_mmio_ar_get & m_arready;

  // R
  assign mmio_r_put           = {m_rdata, m_rresp};
  assign m_rready             = RDY_mmio_r_put;
  assign EN_mmio_r_put        = m_rvalid & RDY_mmio_r_put;

endmodule

`default_nettype wire

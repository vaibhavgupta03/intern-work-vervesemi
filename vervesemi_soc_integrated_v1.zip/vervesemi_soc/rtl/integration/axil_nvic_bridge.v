// ============================================================================
// axil_nvic_bridge.v -- AXI4-Lite slave front-end for vaibhav's nvic_top.
// ----------------------------------------------------------------------------
// nvic_top has a simple wr_en/addr/wr_data + rd_addr/rd_data register port
// plus dedicated cpu_claim / cpu_complete strobes. This bridge:
//   * terminates one AXI4-Lite slave port (8-bit local address from the NoC
//     concentrator, 256 B window)
//   * forwards plain register accesses to the NVIC regfile (map unchanged:
//     0x00 ENABLE_SET..., 0x10 PEND_SET..., 0x40+ PRIO, 0xF0/F4 config,
//     0xF8/FC winner status -- see vic_regfile.v)
//   * adds three *bridge-local* registers in the regfile's unused 0x30 hole:
//       0x30 W : CLAIM    -- pulses cpu_claim   (accept highest-prio IRQ)
//       0x34 W : COMPLETE -- pulses cpu_complete, id = wdata[6:0]
//       0x38 R : IRQSTAT  -- {16'h0, irq_prio[7:0], irq_pending, irq_id[6:0]}
//     0x38 is what interrupt-polling firmware spins on.
// Single outstanding transaction, 1 wait-state, always OKAY (matches the
// AXI-Lite usage of the rest of the SoC).
// ============================================================================
`default_nettype none

module axil_nvic_bridge (
    input  wire        clk,
    input  wire        rst,          // active-high (NVIC convention)

    // ---- AXI4-Lite slave (from NoC concentrator) ----
    input  wire [7:0]  s_awaddr,
    input  wire [2:0]  s_awprot,
    input  wire        s_awvalid,
    output wire        s_awready,
    input  wire [31:0] s_wdata,
    input  wire [3:0]  s_wstrb,
    input  wire        s_wvalid,
    output wire        s_wready,
    output wire [1:0]  s_bresp,
    output reg         s_bvalid,
    input  wire        s_bready,
    input  wire [7:0]  s_araddr,
    input  wire [2:0]  s_arprot,
    input  wire        s_arvalid,
    output wire        s_arready,
    output reg  [31:0] s_rdata,
    output wire [1:0]  s_rresp,
    output reg         s_rvalid,
    input  wire        s_rready,

    // ---- NVIC regfile port ----
    output reg         nvic_wr_en,
    output reg  [7:0]  nvic_addr,
    output reg  [31:0] nvic_wr_data,
    output reg  [7:0]  nvic_rd_addr,
    input  wire [31:0] nvic_rd_data,

    // ---- NVIC CPU-side strobes / status ----
    output reg         cpu_claim,
    output reg         cpu_complete,
    output reg  [6:0]  cpu_complete_id,
    input  wire        irq_pending,
    input  wire [6:0]  irq_id,
    input  wire [7:0]  irq_prio
);

    localparam A_CLAIM    = 8'h30;
    localparam A_COMPLETE = 8'h34;
    localparam A_IRQSTAT  = 8'h38;

    assign s_bresp = 2'b00;
    assign s_rresp = 2'b00;

    // ---------------- write channel ----------------
    reg        aw_got, w_got;
    reg [7:0]  aw_lat;
    reg [31:0] w_lat;

    assign s_awready = ~aw_got & ~s_bvalid;
    assign s_wready  = ~w_got  & ~s_bvalid;

    always @(posedge clk) begin
        if (rst) begin
            aw_got <= 1'b0;  w_got <= 1'b0;
            aw_lat <= 8'h0;  w_lat <= 32'h0;
            s_bvalid <= 1'b0;
            nvic_wr_en <= 1'b0; nvic_addr <= 8'h0; nvic_wr_data <= 32'h0;
            cpu_claim <= 1'b0; cpu_complete <= 1'b0; cpu_complete_id <= 7'h0;
        end else begin
            // default: single-cycle pulses
            nvic_wr_en   <= 1'b0;
            cpu_claim    <= 1'b0;
            cpu_complete <= 1'b0;

            if (s_awvalid & s_awready) begin aw_lat <= s_awaddr; aw_got <= 1'b1; end
            if (s_wvalid  & s_wready ) begin w_lat  <= s_wdata;  w_got  <= 1'b1; end

            if (aw_got & w_got & ~s_bvalid) begin
                case (aw_lat)
                    A_CLAIM:    cpu_claim <= 1'b1;
                    A_COMPLETE: begin cpu_complete <= 1'b1; cpu_complete_id <= w_lat[6:0]; end
                    default: begin
                        nvic_wr_en   <= 1'b1;
                        nvic_addr    <= aw_lat;
                        nvic_wr_data <= w_lat;
                    end
                endcase
                s_bvalid <= 1'b1;
                aw_got   <= 1'b0;
                w_got    <= 1'b0;
            end

            if (s_bvalid & s_bready) s_bvalid <= 1'b0;
        end
    end

    // ---------------- read channel ----------------
    // AR handshake -> 1 wait-state (regfile read mux settles) -> RVALID.
    reg       rd_pend;      // address accepted, data being fetched
    reg [7:0] ar_lat;

    assign s_arready = ~rd_pend & ~s_rvalid;

    always @(posedge clk) begin
        if (rst) begin
            s_rvalid <= 1'b0;
            s_rdata  <= 32'h0;
            nvic_rd_addr <= 8'h0;
            rd_pend  <= 1'b0;
            ar_lat   <= 8'h0;
        end else begin
            if (s_arvalid & s_arready) begin
                nvic_rd_addr <= s_araddr;      // regfile read mux is combinational
                ar_lat  <= s_araddr;
                rd_pend <= 1'b1;
            end
            if (rd_pend) begin
                s_rdata <= (ar_lat == A_IRQSTAT)
                             ? {16'h0, irq_prio, irq_pending, irq_id}
                             : nvic_rd_data;
                s_rvalid <= 1'b1;
                rd_pend  <= 1'b0;
            end
            if (s_rvalid & s_rready) s_rvalid <= 1'b0;
        end
    end

endmodule

`default_nettype wire

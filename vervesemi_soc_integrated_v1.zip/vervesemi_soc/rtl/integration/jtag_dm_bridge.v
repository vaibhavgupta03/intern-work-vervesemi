// ============================================================================
// jtag_dm_bridge.v -- glue between ankit's JTAG DTM (dtm_dmi_rv) and the
// Bluespec debug-host interface of mkSoC (DbgHostIfc, on the Debug clock).
// ----------------------------------------------------------------------------
// Runs entirely on TCK. soc_top.sv wires mkSoC's Debug clock (CLK_dClk) to
// TCK, so the EN/RDY method ports of the debug interface are TCK-synchronous
// and the SyncFIFOs inside mkDebugCDC handle the crossing to the CPU clock.
//
// The 41-bit DMI word gives us addr[6:0] / data[31:0] / op[1:0] per JTAG
// Update-DR. A DbgReq is 72 bits ({cmd[2:0], regno[4:0], addr[31:0],
// wdata[31:0]}), so commands are staged over multiple DMI writes:
//
//   DMI addr  op        meaning
//   ------------------------------------------------------------------
//   0x10      write     stage ADDR   (for DBG_MEM_RD / DBG_MEM_WR)
//   0x11      write     stage WDATA  (for DBG_GPR_WR / DBG_MEM_WR)
//   0x12      write     EXECUTE: data[2:0] = cmd, data[7:3] = regno
//                        cmd: 0=NOP 1=HALT 2=RESUME 3=STEP
//                             4=GPR_RD 5=GPR_WR 6=MEM_RD 7=MEM_WR
//   0x13      read      last response rdata (result of GPR_RD / MEM_RD)
//   0x14      read      status: {22'b0, resp_cnt[7:0], core_halted, resp_fresh}
//
// Responses from mkSoC are auto-drained (EN_debug_getResp whenever RDY) into
// holding registers, so a subsequent DMI read of 0x13/0x14 always returns the
// latest completed command's result. dmi_rsp_* feed the Capture-DR path of
// dtm_dmi_rv.
// ============================================================================
`default_nettype none

module jtag_dm_bridge (
    input  wire        tck,
    input  wire        trst_n,

    // ---- from dtm_dmi_rv ----
    input  wire        dmi_req_valid,
    input  wire [6:0]  dmi_req_addr,
    input  wire [31:0] dmi_req_data,
    input  wire [1:0]  dmi_req_op,       // 1 = read, 2 = write

    // ---- to dtm_dmi_rv (Capture-DR response) ----
    output reg  [31:0] dmi_rsp_data,
    output wire [1:0]  dmi_rsp_status,   // always success

    // ---- to mkSoC debug host interface (bsc EN/RDY ports, TCK domain) ----
    output wire [71:0] dbg_req,          // debug_enqReq_r
    output wire        dbg_req_en,       // EN_debug_enqReq
    input  wire        dbg_req_rdy,      // RDY_debug_enqReq

    input  wire [32:0] dbg_resp,         // debug_getResp = {halted, rdata[31:0]}
    input  wire        dbg_resp_rdy,     // RDY_debug_getResp
    output wire        dbg_resp_en,      // EN_debug_getResp

    input  wire        core_halted       // debug_coreHalted
);

    localparam A_ADDR   = 7'h10;
    localparam A_WDATA  = 7'h11;
    localparam A_EXEC   = 7'h12;
    localparam A_RESP   = 7'h13;
    localparam A_STATUS = 7'h14;

    localparam OP_READ  = 2'd1;
    localparam OP_WRITE = 2'd2;

    assign dmi_rsp_status = 2'b00;

    // ---- staging registers ----
    reg [31:0] stg_addr, stg_wdata;

    // ---- response holding registers (auto-drained) ----
    reg [31:0] resp_rdata;
    reg        resp_fresh;
    reg [7:0]  resp_cnt;

    assign dbg_resp_en = dbg_resp_rdy;    // always drain

    // ---- pending command (waits for RDY of the CDC SyncFIFO) ----
    reg        cmd_pend;
    reg [71:0] cmd_word;

    // EN is only ever high while RDY is high (bsc method-call contract).
    assign dbg_req    = cmd_word;
    assign dbg_req_en = cmd_pend & dbg_req_rdy;

    always @(posedge tck or negedge trst_n) begin
        if (!trst_n) begin
            stg_addr  <= 32'h0;   stg_wdata <= 32'h0;
            cmd_pend  <= 1'b0;    cmd_word   <= 72'h0;
            resp_rdata <= 32'h0;  resp_fresh <= 1'b0;  resp_cnt <= 8'h0;
            dmi_rsp_data <= 32'h0;
        end else begin
            // drain responses into the holding regs
            if (dbg_resp_rdy) begin
                resp_rdata <= dbg_resp[31:0];
                resp_fresh <= 1'b1;
                resp_cnt   <= resp_cnt + 8'd1;
            end

            // DMI request handling
            if (dmi_req_valid) begin
                if (dmi_req_op == OP_WRITE) begin
                    case (dmi_req_addr)
                        A_ADDR:  stg_addr  <= dmi_req_data;
                        A_WDATA: stg_wdata <= dmi_req_data;
                        A_EXEC:  begin
                                   cmd_word <= {dmi_req_data[2:0],   // cmd
                                                dmi_req_data[7:3],   // regno
                                                stg_addr,            // addr
                                                stg_wdata};          // wdata
                                   cmd_pend   <= 1'b1;
                                   resp_fresh <= 1'b0;   // response now stale
                                 end
                        default: ;
                    endcase
                end else if (dmi_req_op == OP_READ) begin
                    case (dmi_req_addr)
                        A_RESP:   dmi_rsp_data <= resp_rdata;
                        A_STATUS: dmi_rsp_data <= {22'b0, resp_cnt, core_halted, resp_fresh};
                        default:  dmi_rsp_data <= 32'h0;
                    endcase
                end
            end

            // command handshake completed this cycle -> clear pending
            if (cmd_pend && dbg_req_rdy)
                cmd_pend <= 1'b0;
        end
    end

endmodule

`default_nettype wire

// ============================================================================
// soc_ctrl.v -- small SoC-level control/status peripheral (NEW, integration).
// ----------------------------------------------------------------------------
// Lives at NoC slot C0.P2 (CPU address 0x4000_0200). Three jobs:
//   1. SoC identification register (sanity read for bring-up).
//   2. UART RX mailbox: vaibhav's uart-ip does not expose received data on
//      its own register file (RBR reads as 0), so uart_top_soc.v exports
//      rx_data/rx_valid as ports and this block latches them bus-readably.
//   3. Software IRQ trigger: writing SWIRQ pulses NVIC irq_in[31:24] lines,
//      so firmware can raise interrupts without external stimulus.
//
// Register map (byte offsets in the 256 B window):
//   0x00 R  : SOC_ID     = 0x5EC0_2026
//   0x04 R  : RX_DATA    = {22'b0, rx_fresh, rx_data[8:0]}   (read clears rx_fresh)
//   0x08 R  : RX_COUNT   = number of bytes received since reset
//   0x0C W  : SWIRQ      -- wdata[7:0] one-cycle pulse on swirq_out[7:0]
//   0x10 R  : IRQSTAT    = {16'h0, irq_prio, irq_pending, irq_id[6:0]} (NVIC live)
// ============================================================================
`default_nettype none

module soc_ctrl (
    input  wire        clk,
    input  wire        rst,          // active-high

    // ---- AXI4-Lite slave (from NoC concentrator) ----
    input  wire [7:0]  s_awaddr,
    input  wire [2:0]  s_awprot,
    input  wire        s_awvalid,
    output wire        s_awready,
    input  wire [31:0] s_wdata,
    input  wire [3:0]  s_wstrb,
    input  wire        s_wvalid,
    output wire        s_wready,
    output wire [1:0]  s_bresp,
    output reg         s_bvalid,
    input  wire        s_bready,
    input  wire [7:0]  s_araddr,
    input  wire [2:0]  s_arprot,
    input  wire        s_arvalid,
    output wire        s_arready,
    output reg  [31:0] s_rdata,
    output wire [1:0]  s_rresp,
    output reg         s_rvalid,
    input  wire        s_rready,

    // ---- UART receive tap (from uart_top_soc) ----
    input  wire [8:0]  uart_rx_data,
    input  wire        uart_rx_valid,

    // ---- NVIC hooks ----
    output reg  [7:0]  swirq_out,       // pulses into nvic irq_in[31:24]
    input  wire        irq_pending,     // NVIC live status (for polling)
    input  wire [6:0]  irq_id,
    input  wire [7:0]  irq_prio
);

    localparam A_SOC_ID   = 8'h00;
    localparam A_RX_DATA  = 8'h04;
    localparam A_RX_COUNT = 8'h08;
    localparam A_SWIRQ    = 8'h0C;
    localparam A_IRQSTAT  = 8'h10;

    localparam [31:0] SOC_ID_VAL = 32'h5EC0_2026;

    assign s_bresp = 2'b00;
    assign s_rresp = 2'b00;

    // ---- UART RX mailbox ----
    reg [8:0]  rx_byte;
    reg        rx_fresh;
    reg [31:0] rx_count;

    // ---------------- write channel ----------------
    reg        aw_got, w_got;
    reg [7:0]  aw_lat;
    reg [31:0] w_lat;

    assign s_awready = ~aw_got & ~s_bvalid;
    assign s_wready  = ~w_got  & ~s_bvalid;

    always @(posedge clk) begin
        if (rst) begin
            aw_got <= 1'b0; w_got <= 1'b0; aw_lat <= 8'h0; w_lat <= 32'h0;
            s_bvalid <= 1'b0; swirq_out <= 8'h0;
        end else begin
            swirq_out <= 8'h0;                       // one-cycle pulse
            if (s_awvalid & s_awready) begin aw_lat <= s_awaddr; aw_got <= 1'b1; end
            if (s_wvalid  & s_wready ) begin w_lat  <= s_wdata;  w_got  <= 1'b1; end
            if (aw_got & w_got & ~s_bvalid) begin
                if (aw_lat == A_SWIRQ) swirq_out <= w_lat[7:0];
                s_bvalid <= 1'b1;
                aw_got <= 1'b0; w_got <= 1'b0;
            end
            if (s_bvalid & s_bready) s_bvalid <= 1'b0;
        end
    end

    // ---------------- read channel + RX mailbox ----------------
    assign s_arready = ~s_rvalid;

    always @(posedge clk) begin
        if (rst) begin
            s_rvalid <= 1'b0; s_rdata <= 32'h0;
            rx_byte <= 9'h0; rx_fresh <= 1'b0; rx_count <= 32'h0;
        end else begin
            if (uart_rx_valid) begin
                rx_byte  <= uart_rx_data;
                rx_fresh <= 1'b1;
                rx_count <= rx_count + 32'd1;
            end
            if (s_arvalid & s_arready) begin
                case (s_araddr)
                    A_SOC_ID:   s_rdata <= SOC_ID_VAL;
                    A_RX_DATA:  begin
                                  s_rdata  <= {22'b0, rx_fresh, rx_byte};
                                  rx_fresh <= 1'b0;   // read side-effect
                                end
                    A_RX_COUNT: s_rdata <= rx_count;
                    A_IRQSTAT:  s_rdata <= {16'h0, irq_prio, irq_pending, irq_id};
                    default:    s_rdata <= 32'h0;
                endcase
                s_rvalid <= 1'b1;
            end
            if (s_rvalid & s_rready) s_rvalid <= 1'b0;
        end
    end

endmodule

`default_nettype wire

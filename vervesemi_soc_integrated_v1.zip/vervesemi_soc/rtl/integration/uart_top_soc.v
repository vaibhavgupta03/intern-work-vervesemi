// ============================================================================
// uart_top_soc.v -- SoC-integration variant of vaibhav's uart_top.v.
// Differences vs the original (which is kept untouched in rtl/uart/):
//   1. module renamed uart_top -> uart_top_soc
//   2. rx_data/rx_valid of uart_receiver and tx_busy/tx_done of
//      uart_transmitter, which were left dangling, are exported as ports
//      (rx_data_o/rx_valid_o/tx_busy_o/tx_done_o) so soc_ctrl.v can expose
//      received bytes to the CPU and the NVIC can see UART events.
//   3. the Verilator functional-coverage monitor block was removed (it is
//      testbench instrumentation, and its hierarchical references are not
//      accepted by all tools).
// Everything else is byte-identical to the original.
// ============================================================================
`timescale 1ns/1ps

module uart_top_soc #(
    parameter AXI_ADDR_WIDTH = 32,
    parameter AXI_DATA_WIDTH = 32,
    parameter CLOCK_FREQUENCY = 100_000_000
)(
    input  wire                       clk,
    input  wire                       rst,

    // ── Physical UART Pins ────────────────────────────────
    input  wire                       rx,
    output wire                       tx,

    // ── AXI4-Lite Write Address Channel ───────────────────
    input  wire [AXI_ADDR_WIDTH-1:0]  s_awaddr,
    input  wire                       s_awvalid,
    output wire                       s_awready,

    // ── AXI4-Lite Write Data Channel ──────────────────────
    input  wire [AXI_DATA_WIDTH-1:0]  s_wdata,
    input  wire [3:0]                 s_wstrb,
    input  wire                       s_wvalid,
    output wire                       s_wready,

    // ── AXI4-Lite Write Response Channel ──────────────────
    output wire [1:0]                 s_bresp,
    output wire                       s_bvalid,
    input  wire                       s_bready,

    // ── AXI4-Lite Read Address Channel ────────────────────
    input  wire [AXI_ADDR_WIDTH-1:0]  s_araddr,
    input  wire                       s_arvalid,
    output wire                       s_arready,

    // ── AXI4-Lite Read Data Channel ───────────────────────
    output wire [AXI_DATA_WIDTH-1:0]  s_rdata,
    output wire [1:0]                 s_rresp,
    output wire                       s_rvalid,
    input  wire                       s_rready,

    // ── SoC integration taps (NEW): receive data + TX status ──
    output wire [8:0]                 rx_data_o,
    output wire                       rx_valid_o,
    output wire                       tx_busy_o,
    output wire                       tx_done_o
);

    // ── Internal Interconnect Wires ───────────────────────
    wire        regfile_wr_en;
    wire [4:0]  regfile_wr_addr;
    wire [15:0] regfile_wr_data;
    wire [4:0]  regfile_rd_addr;
    wire [15:0] regfile_rd_data;
    wire [15:0] clk_val; 

    // Register Output Configuration Values
    wire [15:0] thr_val;
    wire [15:0] dll_val;
    wire [15:0] dlh_val;
    wire [15:0] dlf_val;
    wire [15:0] lcr_val;

    // Baud Rate Generator Wires
    wire        oversample_tick;
    wire [4:0]  oversample_factor;

    // ── 1. Instance: AXI4-Lite Slave Bus Protocol Wrapper ──
    axi4lite_slave #(
        .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
        .AXI_DATA_WIDTH(AXI_DATA_WIDTH)
    ) u_axi_slave (
        .clk(clk), .rst(rst),
        .s_awaddr(s_awaddr), .s_awvalid(s_awvalid), .s_awready(s_awready),
        .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wvalid(s_wvalid), .s_wready(s_wready),
        .s_bresp(s_bresp), .s_bvalid(s_bvalid), .s_bready(s_bready),
        .s_araddr(s_araddr), .s_arvalid(s_arvalid), .s_arready(s_arready),
        .s_rdata(s_rdata), .s_rresp(s_rresp), .s_rvalid(s_rvalid), .s_rready(s_rready),
        
        .regfile_wr_en(regfile_wr_en),
        .regfile_wr_addr(regfile_wr_addr),
        .regfile_wr_data(regfile_wr_data),
        .regfile_rd_addr(regfile_rd_addr),
        .regfile_rd_data(regfile_rd_data)
    );

    // ── 2. Instance: Unified Config Register File ──────────
    uart_regfile u_regfile (
        .clk(clk), .rst(rst),
        .wr_en(regfile_wr_en),
        .addr(regfile_wr_addr),
        .wr_data(regfile_wr_data),
        .rd_addr(regfile_rd_addr),
        .rd_data(regfile_rd_data),

        .thr_val(thr_val),
        .dll_val(dll_val),
        .dlh_val(dlh_val),
        .dlf_val(dlf_val),
        .lcr_val(lcr_val),
        
        .rbr_val(), .ier_val(), .iir_val(), .fcr_val(), 
        .mcr_val(), .lsr_val(), .msr_val(), .mode_val(), 
        .clk_val(clk_val), .rxthr_val(), .txthr_val(), .timeout_val()
    );

    // ── 3. Instance: Clock Divider / Baud Rate Generator ───
    baudrategenerator #(
        .CLOCK_FREQUENCY(CLOCK_FREQUENCY)
    ) u_baud_gen (
        .clk(clk),
        .rst(rst),
        .dll_val(dll_val),
        .dlh_val(dlh_val),
        .dlf_val(dlf_val),
        .os_sel(clk_val[3:2]), 
        .oversample_tick(oversample_tick),
        .oversample_factor(oversample_factor)
    );

    // ── 4. Instance: UART Serial Transmitter (Tx) ──────────
    wire tx_start_pulse = regfile_wr_en && (regfile_wr_addr == 5'h00) && (lcr_val[9] == 1'b0);

    uart_transmitter u_tx (
        .clk(clk),
        .rst(rst),
        .tx_start(tx_start_pulse),
        .oversample_tick(oversample_tick),
        .tx_data(regfile_wr_data[8:0]),
        .word_len_sel(lcr_val[2:0]),
        .stop_bits_sel(lcr_val[4:3]),
        .parity_sel(lcr_val[7:5]),
        .break_ctrl(lcr_val[8]),
        .oversample_factor(oversample_factor),
        .tx(tx),
        .tx_done(tx_done_o),
        .tx_busy(tx_busy_o)
    );

    // ── 5. Instance: UART Serial Receiver (Rx) ─────────────
    uart_receiver u_rx (
        .clk(clk),
        .rst(rst),
        .oversample_tick(oversample_tick),
        .rx(rx),
        .word_len_sel(lcr_val[2:0]),
        .stop_bits_sel(lcr_val[4:3]),
        .parity_sel(lcr_val[7:5]),
        .oversample_factor(oversample_factor),
        .rx_data(rx_data_o),
        .rx_valid(rx_valid_o),
        .rx_busy(),
        .frame_error(),
        .parity_error(),
        .break_detect()
    );

    // (functional-coverage monitor block of the original uart_top.v removed --
    //  it is Verilator-TB instrumentation with hierarchical references, not RTL.)

endmodule
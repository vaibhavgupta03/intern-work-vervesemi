// ============================================================================
// dtm_dmi_rv.v -- SoC-integration variant of ankit's dtm_dmi.v.
// Differences vs the original (kept untouched in rtl/debug/):
//   * NEW capture path: on Capture-DR with the DMI instruction selected, the
//     response from the debug module ({7'b0, dmi_rsp_data, dmi_rsp_status}) is
//     parallel-loaded into the shift register, so the host can SHIFT OUT read
//     results. The original could only shift requests in (tdo showed stale
//     request bits, making DMI reads impossible).
//   * NEW inputs: capture_dr, dmi_rsp_data, dmi_rsp_status.
// Shift/update behaviour is otherwise identical (41-bit DMI: addr[40:34],
// data[33:2], op[1:0]; DMI instruction code 0x11).
// ============================================================================
`timescale 1ns / 1ps

module dtm_dmi_rv (
    input  wire tck,
    input  wire trst_n,
    input  wire tdi,

    // Control from TAP
    input  wire shift_dr,
    input  wire capture_dr,          // NEW: derived from tap_state == CAPTURE_DR
    input  wire update_dr,
    input  wire [4:0] ir_out,

    output reg  tdo,

    // Parallel DMI Bus Output to Debug Module (DM)
    output reg        dmi_req_valid,
    output reg [6:0]  dmi_req_addr,
    output reg [31:0] dmi_req_data,
    output reg [1:0]  dmi_req_op,

    // NEW: Parallel DMI response input from the debug bridge
    input  wire [31:0] dmi_rsp_data,
    input  wire [1:0]  dmi_rsp_status   // 0 = success (RISC-V dmistat)
);

    // 41-bit shift register (7-bit addr + 32-bit data + 2-bit op)
    reg [40:0] dmi_shift_reg;

    // DMI Instruction code is 0x11
    wire is_dmi = (ir_out == 5'h11);

    // --- Capture + Shift Logic ---
    always @(posedge tck or negedge trst_n) begin
        if (!trst_n) begin
            dmi_shift_reg <= 41'b0;
            tdo <= 1'b0;
        end else begin
            if (capture_dr && is_dmi) begin
                // NEW: present the last response for shifting out
                dmi_shift_reg <= {7'b0, dmi_rsp_data, dmi_rsp_status};
            end else if (shift_dr && is_dmi) begin
                // Shift in TDI from MSB, shift right towards LSB
                dmi_shift_reg <= {tdi, dmi_shift_reg[40:1]};
                tdo <= dmi_shift_reg[0];
            end
        end
    end

    // --- Update Logic (Generate Parallel Request) ---
    always @(posedge tck or negedge trst_n) begin
        if (!trst_n) begin
            dmi_req_valid <= 1'b0;
            dmi_req_addr  <= 7'b0;
            dmi_req_data  <= 32'b0;
            dmi_req_op    <= 2'b0;
        end else begin
            if (update_dr && is_dmi) begin
                // [40:34] -> Address, [33:2] -> Data, [1:0] -> Op
                dmi_req_valid <= 1'b1;
                dmi_req_addr  <= dmi_shift_reg[40:34];
                dmi_req_data  <= dmi_shift_reg[33:2];
                dmi_req_op    <= dmi_shift_reg[1:0];
            end else begin
                dmi_req_valid <= 1'b0;   // auto-clear after 1 tck
            end
        end
    end

endmodule

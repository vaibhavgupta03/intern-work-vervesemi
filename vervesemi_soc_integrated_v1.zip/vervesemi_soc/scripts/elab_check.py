#!/usr/bin/env python3
"""Full-design elaboration check of soc_top using the slang SystemVerilog
front-end (pip install pyslang). Two modes:

  python3 scripts/elab_check.py            # pre-bsc : uses sim_smoke/mkSoC_stub.sv
  python3 scripts/elab_check.py --real     # post-bsc: uses bsv/verilog/*.v

Exit code 0 = design elaborates cleanly (no errors)."""
import sys, glob, os
import pyslang

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def files(real):
    fs  = sorted(glob.glob(f"{ROOT}/rtl/noc/*.sv"))
    fs += sorted(glob.glob(f"{ROOT}/rtl/uart/*.v"))
    fs += sorted(glob.glob(f"{ROOT}/rtl/nvic/*.v"))
    fs += [f"{ROOT}/rtl/debug/jtag_tap.v", f"{ROOT}/rtl/debug/jtag_register.v"]
    fs += sorted(glob.glob(f"{ROOT}/rtl/integration/*.sv"))
    fs += sorted(glob.glob(f"{ROOT}/rtl/integration/*.v"))
    fs += [f"{ROOT}/tb/tb_soc_top.sv"]
    if real:
        fs += sorted(glob.glob(f"{ROOT}/bsv/verilog/*.v"))
    else:
        fs += [f"{ROOT}/sim_smoke/mkSoC_stub.sv"]
    # exclude the unmodified original that uart_top_soc.v replaces
    fs = [f for f in fs if not f.endswith("rtl/uart/uart_top.v")]
    return fs

def main():
    real = "--real" in sys.argv
    drv = pyslang.driver.Driver()
    drv.addStandardArgs()
    args = ["slang", "--top", "soc_top", "--top", "tb_soc_top", "--timescale", "1ns/1ps"] + files(real)
    if not drv.parseCommandLine(" ".join(f'"{a}"' if " " in a else a for a in args)):
        sys.exit(2)
    if not drv.processOptions():
        sys.exit(2)
    ok = drv.parseAllSources()
    comp = drv.createCompilation()
    drv.reportCompilation(comp, True)
    ok &= bool(drv.reportDiagnostics(False))
    print(f"[elab_check] {'REAL mkSoC.v' if real else 'stub mkSoC'} : "
          f"{'CLEAN' if ok else 'ERRORS'} ({len(files(real))} files)")
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()

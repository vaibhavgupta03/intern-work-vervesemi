# Example Flow — one instruction through the whole SoC

The demo firmware (`fw/soc_demo.py`) exercises every block. This document
walks through **one representative instruction** in cycle-level detail, then
summarizes the full program so you can explain the SoC end-to-end.

---

## Part 1 — anatomy of a single MMIO store

Take the firmware's UART write:

```asm
lui  x1, 0x40000        # x1 = 0x4000_0000 (peripheral base)
addi x2, x0, 0x56       # x2 = 'V'
sh   x2, 0x000(x1)      # store halfword to UART THR (0x4000_0000)
```

**① Fetch (mkCore, CPU clock).** The PC issues an AXI4-Lite read on the
`imem` master. The 3:1 crossbar (`AXI4LiteXbar.bsv`) grants it (imem has top
priority), the BRAM returns the 32-bit instruction, and the 5-stage pipeline
decodes `SH`.

**② Execute.** The ALU computes the effective address `0x4000_0000`;
`storeFormat` places 0x0056 in the correct AXI byte lanes and builds
`wstrb = 4'b0011` (halfword at offset 0).

**③ Memory stage → splitter (`AXI4LiteSplit.bsv`, NEW).** The core's `dmem`
master issues AW (`awaddr=0x4000_0000`) + W. The splitter inspects
`addr[31:28] == 4'h4` → this is MMIO, so the transaction is routed to the
`hi` FIFOs and a routing tag is queued (so the write response B will later be
returned in order). Had the address been below the window (e.g. the result
table at `0x400`), it would have gone to `lo` → crossbar → BRAM instead.

**④ Off-chip boundary (`bsc_axi_shim.sv`).** bsc exports the `hi` master as
Get/Put method ports (`mmio_aw_get` + `RDY`/`EN`). The shim maps them to
standard AXI4-Lite: `RDY` (fifo not empty) becomes `awvalid`, and
`EN = RDY & awready` pops the FIFO exactly when the NoC accepts the beat.

**⑤ Star-hub NoC (`axil_hub.sv`, master port M0).** `soc_top` first strips
the base: the hub sees `awaddr = 0x000`. The hub checks `[31:12]==0` (in
range), decodes `[11:10] = 00` → concentrator 0, runs round-robin arbitration
against master M1 (idle, so same-cycle grant), and locks the write path
M0→C0 until the B handshake.

**⑥ Concentrator (`axil_concentrator.sv`).** Decodes `[9:8] = 00` →
peripheral 0 (UART), forwards `awaddr[7:0] = 0x00`, and registers the
selection at the AW handshake so the W and B beats steer to the same
peripheral.

**⑦ UART (`uart_top_soc.v`).** The lane fixer in `soc_top` sees
`wstrb = 0011` (data already in the low lanes, passes through). The UART's
AXI slave latches address and data, pulses `regfile_wr_en`, and because
`addr==0x00` with `LCR.DLAB==0` this is a THR write → `tx_start` fires. The
transmitter shifts out start bit, 8 data bits (LSB first: 0,1,1,0,1,0,1,0),
stop bit — one bit per 16 oversample ticks. With the TB loopback the receiver
samples the same waveform, and 10 bit-times later pulses `rx_valid` with
`rx_data = 0x56`.

**⑧ Side effects.** `rx_valid` does two things simultaneously:
`soc_ctrl` latches 0x56 into its RX mailbox (fresh=1, count++), and NVIC
`irq_in[16]` is pulsed → `pend_array` latches pending bit 16 permanently
(until claimed) even though the pulse was one cycle.

**⑨ Response path.** The UART returned `bresp=OKAY` at ⑦; it rides back
concentrator → hub (path unlocks) → shim (`EN_mmio_b_put`) → splitter (tag
says "hi", forwarded to the core in order) → the pipeline's store completes
and retires. Total: ~8–10 cycles of interconnect latency, invisible to
software.

## Part 2 — the whole demo program

```
step  action                                            block exercised
----  ------------------------------------------------  -------------------
 1    LCR(DLAB=1) → DLL=1, DLH=0, DLF=0 → LCR=8N1        UART config regs
 2    burn ~65k cycles (baud counter wrap, see README)   -
 3    write THR='V'                                      UART TX (⑦ above)
 4    prio[16]=9, prio[24]=5, enable {16,24}             NVIC regfile via bridge
 5    write SOC_CTRL.SWIRQ=1 → pulses irq_in[24]         soc_ctrl → NVIC
 6    poll NVIC.IRQSTAT until pending:
        winner must be 24 (prio 5 beats 9)               priority encoder
      CLAIM (clears pend[24], current_prio=5)            nvic_controller FSM
      COMPLETE(24) (pops priority stack)
 7    poll SOC_CTRL.RX_COUNT until the looped-back 'V'
      arrives; read RX_DATA mailbox                      UART RX + mailbox
 8    poll IRQSTAT again: now irq16 (uart-rx) wins;
      CLAIM + COMPLETE it                                nested-priority logic
 9    read SOC_ID (0x5EC02026) and the scratch
      peripheral ID (0xA5A50003 = NoC slot C0.P3)        full NoC read path
10    write 0x015A5234 to scratch reg, read it back      NoC write+read
11    store result table to BRAM 0x400, magic 0xC0DEC0DE splitter lo-path
      (on any poll timeout: 0xBAD0000x instead)
```

Every value the program produces is checked by `tb/tb_soc_top.sv` via the
`peekWord` backdoor, and the UART byte is additionally decoded off the
physical `uart_tx` pin by a serial monitor.

## Part 3 — the debug flow (JTAG, after the program finishes)

```
host                     TAP/DTM                bridge              mkSoC
----                     -------                ------              -----
TMS seq: Test-Logic-Reset → Run-Test/Idle
IR scan  0x11 (DMI)
DR scan  41b {addr=0x12, data=1, op=write}
                         Update-DR pulses
                         dmi_req_valid    →     stages DbgReq
                                                {cmd=HALT}     →    CDC SyncFIFO
                                                                    (tck→cpu clk)
                                                                    DebugModule:
                                                                    core.reqHalt(True)
                                                               ←    DbgResp{halted}
                                          ←     auto-drained into
                                                resp regs
DR scan  read 0x14 (STATUS)  ← Capture-DR loads {resp_cnt, halted, fresh}
  → host sees halted=1; pipeline is frozen mid-program
DR scan  {addr=0x12, data=2 (RESUME)} → core runs again
```

The same mechanism does single-step (`cmd=3`), GPR read/write (`cmd=4/5`,
regno in `data[7:3]`) and memory read/write (`cmd=6/7`, using the staged
ADDR/WDATA registers at DMI 0x10/0x11) — memory accesses go through the debug
module's **own AXI master** on the crossbar, so the halted pipeline is not
disturbed. All of it is demonstrated at the end of `tb_soc_top.sv`.

## Why this architecture (talking points)

* **Memory stays inside the Bluespec island** — zero latency added to
  fetch/load/store of program data; only true MMIO pays the NoC latency.
* **The splitter (not the NoC) does the coarse decode** — the NoC keeps its
  verified 4 KiB flat map; adding a peripheral means picking a free C.P slot.
* **Debug clock = TCK** — the existing `mkDebugCDC` SyncFIFOs are reused as
  the JTAG clock-domain crossing; no new CDC logic was needed.
* **All glue is in `rtl/integration/`** — every intern IP remains bit-exact,
  so each team member's original verification results remain valid.

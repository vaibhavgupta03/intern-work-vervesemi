# Verification Guide — how to prove the integrated SoC works

Follow the steps in order. Each step verifies one layer; if a step fails you
know exactly which layer broke. Steps 1–3 need only python3 (+ `pip install
pyslang yowasp-yosys`); steps 4–6 need `bsc` and `verilator` (>= 5.0).

---

## Step 0 — regenerate the firmware image

```
make fw
```
Expected: `fw/soc_demo.hex` with 79 instruction words. This is the demo
program described in `docs/EXAMPLE_FLOW.md`.

## Step 1 — static elaboration of the full SoC (no tools beyond python)

```
make lint
```
This compiles **every** RTL file plus `soc_top.sv` and `tb_soc_top.sv` with
the slang SystemVerilog front-end and elaborates the whole hierarchy (a stub
stands in for the not-yet-generated `mkSoC`).

Expected output:
```
Build succeeded: 0 errors, 0 warnings
[elab_check] stub mkSoC : CLEAN (36 files)
```
What this proves: all module boundaries, port widths, parameter overrides and
generate loops in the integration are consistent — the most common class of
integration bug is already excluded here.

## Step 2 — peripheral-subsystem smoke test (no bsc/verilator needed)

```
make smoke        # or: bash sim_smoke/run_smoke.sh
```
Test 1 builds a cycle-accurate C++ model (yosys CXXRTL) of exactly the
peripheral cluster of `soc_top.sv` (UART + NVIC + bridge + soc_ctrl, UART TX
looped to RX) and drives it with an AXI4-Lite bus-functional model playing
the CPU role. Expected: `SMOKE TEST PASSED (0 failures)` with these checks:

1. SOC_ID reads `0x5EC02026`
2. UART: configure LCR/DLL/DLH/DLF, transmit `'A'`, receive it back through
   the loopback, byte appears in the soc_ctrl RX mailbox with the fresh flag
3. fresh flag clears on read
4. NVIC: rx-pulse was latched in `pend_array`; after enabling irq16 it wins
5. software-triggered irq24 (priority 5 < 9) preempts as the new winner
6. CLAIM/COMPLETE of 24, then 16, ends with no interrupt pending
7. ENABLE register reads back through the AXI bridge

Test 2 does the same for the debug path: JTAG TAP state machine → IR=0x11 →
41-bit DMI scans → the bridge assembles a 72-bit `DbgReq` with the correct
`cmd/regno/addr/wdata` fields → a response injected on the debug-host side is
shifted back out over TDO. Expected: `SMOKE TEST PASSED (0 failures)`.

*(These two tests already passed in the environment where this package was
assembled; re-run them to reproduce.)*

## Step 3 — the original per-IP testbenches still pass

Nothing in `rtl/noc`, `rtl/nvic`, `rtl/uart`, `rtl/debug`, `bsv/src` was
modified, so each intern's own verification still applies (NoC: 100% coverage
Verilator suite; UART: tx_rx_tb + spec checkers; NVIC: per-module TBs; debug:
jtag_*_tb). If your professor asks "did integration break the IPs?" — run
those original suites from the original repo unchanged.

## Step 4 — compile the Bluespec side (needs bsc)

```
make bluesim              # optional: core-only regression, all 7 programs
make bsv-verilog          # generates bsv/verilog/mkSoC.v
```
`make bluesim` runs the intern's own self-checking core tests (ALU, FORWARD,
LOADUSE, BRANCH, MULDIV, TRAP, ILLEGAL) — they must all still print `PASS`,
which proves the new `AXI4LiteSplit` did not disturb the memory path (all
those programs use addresses below the MMIO window).

After `make bsv-verilog`, **open `bsv/verilog/mkSoC.v` and check the port
list** against `rtl/integration/bsc_axi_shim.sv` and the `u_soc` instance in
`soc_top.sv`. bsc's naming convention is deterministic
(`mmio_aw_get`, `EN_mmio_aw_get`, `RDY_mmio_aw_get`, `CLK_dClk`, ...) but this
is the one thing that could not be machine-checked without bsc — fix any
mismatch in the shim, not in the generated file.

Then re-run the elaboration against the real generated Verilog:
```
make lint-real            # must again be CLEAN
```

## Step 5 — full-SoC simulation (needs verilator)

```
make sim                  # or: make sim-waves  (writes soc_top.vcd)
```
This runs `tb/tb_soc_top.sv`: loads `fw/soc_demo.hex` through the backdoor,
lets the CPU run, and checks the firmware's result table plus the UART line:

```
  ok: result magic        = 0xc0dec0de     <- firmware completed every step
  ok: first irq id  (sw)  = 0x00000018     <- NVIC delivered irq24 first
  ok: uart rx byte        = 0x00000056     <- 'V' made it TX->RX->mailbox
  ok: second irq id (rx)  = 0x00000010     <- uart-rx irq16 delivered second
  ok: SOC_ID              = 0x5ec02026
  ok: scratch periph ID   = 0xa5a50003     <- read through hub+concentrator
  ok: scratch readback    = 0x015a5234     <- write+read through full NoC
  ok: uart TX line byte   = 0x00000056     <- decoded off the physical pin
  ok: jtag: core halted   = 0x00000001     <- DMI HALT over real JTAG pins
  ok: jtag: core resumed  = 0x00000000
=== TB PASS: integrated SoC works end-to-end ===
```

If the result magic reads `0xBAD00001/2/3` instead, a firmware poll timed out
at step 1/2/3 (NVIC pending / UART RX / second IRQ) — look at the VCD around
the corresponding peripheral.

## Step 6 — what to show the professor

1. `make lint` output (whole-SoC elaboration clean)
2. `make smoke` transcripts (both subsystems functionally verified)
3. `make bluesim` transcript (core regression unaffected)
4. `make sim` transcript (the end-to-end run above)
5. `soc_top.vcd` opened in GTKWave showing one MMIO store travelling
   core → splitter → shim → hub → concentrator → UART (see EXAMPLE_FLOW.md
   for exactly which signals to display)

## Known limitations (state them, don't hide them)

* Interrupt delivery to the core is by polling (`IRQSTAT`), because the
  RV32IM core has no `mip/mie` external-interrupt support yet. `irq_out` is
  already wired for the future `meip` hookup.
* The smoke tests build the NVIC at 32 sources for model size; `soc_top.sv`
  uses the full 128. Step 5 covers the 128-source build.
* The bsc-generated port names in `bsc_axi_shim.sv`/`soc_top.sv` follow bsc's
  documented convention but must be eyeballed once after `make bsv-verilog`
  (step 4) — that is a 2-minute check.
* One AXI master port of the NoC hub is tied off (reserved for a future DMA
  or debug-to-peripheral master).

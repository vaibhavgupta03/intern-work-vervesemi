#!/usr/bin/env python3
"""soc_demo -- example firmware for the integrated SoC.

Exercises every block: RISC-V core (from BRAM) -> AXI splitter -> NoC ->
UART (TX 'V', loopback RX) -> NVIC (sw irq + uart-rx irq, claim/complete)
-> soc_ctrl (SOC_ID, RX mailbox, SWIRQ) -> scratch peripheral (NoC C0.P3).

Result table written to BRAM at byte 0x400 (word 0x100):
  +0x00 magic     0xC0DEC0DE when the whole flow completed, 0xBAD000xx on a
                  poll timeout at step xx
  +0x04 first claimed irq id   (expect 24 : software-triggered, prio 5)
  +0x08 uart rx byte           (expect 0x56 'V', looped tx->rx)
  +0x0C second claimed irq id  (expect 16 : uart-rx interrupt, prio 9)
  +0x10 SOC_ID                 (expect 0x5EC02026)
  +0x14 scratch periph ID      (expect 0xA5A50003, NoC slot C0.P3)
  +0x18 scratch reg readback   (expect 0x015A5234)

Usage: python3 soc_demo.py > soc_demo.hex
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "bsv", "verif", "mem"))
from asm import (LUIi, ADDI, ANDI, SW, SH, LW, BNE, BEQ, JAL, ADD)

BASE_HI   = 0x40000          # LUI value for 0x4000_0000
UART      = 0x000            # C0.P0
NVIC      = 0x100            # C0.P1
CTRL      = 0x200            # C0.P2
SCRATCH   = 0x300            # C0.P3
RESULT    = 0x400            # BRAM result table (byte address)

# ---------------------------------------------------------------------------
# tiny two-pass label assembler on top of asm.py
#   item = int                     -> fixed instruction word
#   item = ("label", name)         -> marks a position
#   item = (fn, name)              -> fn(byte_offset_to_label) at resolve time
# ---------------------------------------------------------------------------
def assemble(items):
    labels, pc = {}, 0
    for it in items:
        if isinstance(it, tuple) and it[0] == "label":
            labels[it[1]] = pc
        else:
            pc += 4
    words, pc = [], 0
    for it in items:
        if isinstance(it, tuple) and it[0] == "label":
            continue
        if isinstance(it, tuple):
            fn, name = it
            words.append(fn(labels[name] - pc))
        else:
            words.append(it)
        pc += 4
    return words

def prog():
    P = []
    # x1 = peripheral base 0x4000_0000 ; x31 = fail code scratch
    P += [LUIi(1, BASE_HI)]

    # ---- 1. UART configuration (16-bit regs -> SH; lane fixer in soc_top) ----
    P += [ADDI(2, 0, 0x203), SH(2, 1, UART + 0x06)]   # LCR: DLAB=1, 8-bit
    P += [ADDI(2, 0, 1),     SH(2, 1, UART + 0x00)]   # DLL = 1
    P += [ADDI(2, 0, 0),     SH(2, 1, UART + 0x02)]   # DLH = 0
    P += [ADDI(2, 0, 0),     SH(2, 1, UART + 0x0E)]   # DLF = 0
    P += [ADDI(2, 0, 0x003), SH(2, 1, UART + 0x06)]   # LCR: DLAB=0, 8N1
    P += [ADDI(2, 0, 0),     SH(2, 1, UART + 0x12)]   # CLK: os_sel=00 (16x)

    # ---- 2. wait out the baud-counter wrap (~65536 cpu cycles) --------------
    # (the divider register starts at 0, so the free-running 16-bit counter
    #  must wrap once before the first oversample tick -- see docs)
    P += [LUIi(3, 16)]                                #  x3 = 16<<12 = 65536
    P += [("label", "delay")]
    P += [ADDI(3, 3, -1)]
    P += [(lambda off: BNE(3, 0, off), "delay")]

    # ---- 3. transmit 'V' (0x56); it loops back into the receiver ------------
    P += [ADDI(2, 0, 0x56), SH(2, 1, UART + 0x00)]    # THR = 'V'

    # ---- 4. NVIC: prio[16]=9, prio[24]=5, enable both ------------------------
    P += [ADDI(2, 0, 9),  SW(2, 1, NVIC + 0x40 + 16)] # PRIO[16] (uart rx)
    P += [ADDI(2, 0, 5),  SW(2, 1, NVIC + 0x40 + 24)] # PRIO[24] (sw irq)
    P += [LUIi(2, 0x01010), SW(2, 1, NVIC + 0x00)]    # ENABLE_SET_0 = (1<<16)|(1<<24)

    # ---- 5. software-trigger irq24 via soc_ctrl ------------------------------
    P += [ADDI(2, 0, 1), SW(2, 1, CTRL + 0x0C)]       # SWIRQ bit0 -> irq_in[24]

    # ---- 6. poll NVIC IRQSTAT until pending, expect winner id=24 -------------
    P += [LUIi(6, 16)]                                # timeout counter
    P += [("label", "poll1")]
    P += [ADDI(6, 6, -1)]
    P += [(lambda off: BEQ(6, 0, off), "fail1")]
    P += [LW(4, 1, NVIC + 0x38)]                      # {prio, pending, id}
    P += [ANDI(5, 4, 0x80)]                           # pending bit
    P += [(lambda off: BEQ(5, 0, off), "poll1")]
    P += [ANDI(5, 4, 0x7F)]                           # id
    P += [SW(5, 0, RESULT + 0x04)]                    # result: first irq id
    P += [SW(0, 1, NVIC + 0x30)]                      # CLAIM
    P += [SW(5, 1, NVIC + 0x34)]                      # COMPLETE (id)

    # ---- 7. wait for the looped-back UART byte -------------------------------
    P += [LUIi(6, 16)]
    P += [("label", "poll2")]
    P += [ADDI(6, 6, -1)]
    P += [(lambda off: BEQ(6, 0, off), "fail2")]
    P += [LW(4, 1, CTRL + 0x08)]                      # RX_COUNT
    P += [(lambda off: BEQ(4, 0, off), "poll2")]
    P += [LW(4, 1, CTRL + 0x04)]                      # RX_DATA {fresh, data}
    P += [ANDI(4, 4, 0x1FF)]
    P += [SW(4, 0, RESULT + 0x08)]                    # result: rx byte

    # ---- 8. uart-rx interrupt (irq16) should be pending now ------------------
    P += [LUIi(6, 16)]
    P += [("label", "poll3")]
    P += [ADDI(6, 6, -1)]
    P += [(lambda off: BEQ(6, 0, off), "fail3")]
    P += [LW(4, 1, NVIC + 0x38)]
    P += [ANDI(5, 4, 0x80)]
    P += [(lambda off: BEQ(5, 0, off), "poll3")]
    P += [ANDI(5, 4, 0x7F)]
    P += [SW(5, 0, RESULT + 0x0C)]                    # result: second irq id
    P += [SW(0, 1, NVIC + 0x30)]                      # CLAIM
    P += [SW(5, 1, NVIC + 0x34)]                      # COMPLETE

    # ---- 9. identification reads ---------------------------------------------
    P += [LW(4, 1, CTRL + 0x00), SW(4, 0, RESULT + 0x10)]     # SOC_ID
    P += [LW(4, 1, SCRATCH + 0x00), SW(4, 0, RESULT + 0x14)]  # periph ID reg

    # ---- 10. scratch-register write/readback through the whole NoC path ------
    P += [LUIi(2, 0x15A5), ADDI(2, 2, 0x234)]         # x2 = 0x15A5234? no:
    # LUI 0x15A5 -> 0x015A5000 ; +0x234 -> 0x015A5234
    P += [SW(2, 1, SCRATCH + 0x04)]                   # reg1 of axil_periph_reg
    P += [LW(4, 1, SCRATCH + 0x04)]
    P += [SW(4, 0, RESULT + 0x18)]                    # result: readback

    # ---- success ---------------------------------------------------------------
    P += [LUIi(2, 0xC0DEC)]                           # 0xC0DEC000
    P += [ADDI(2, 2, 0x0DE)]                          # 0xC0DEC0DE
    P += [SW(2, 0, RESULT + 0x00)]
    P += [("label", "halt"), (lambda off: JAL(0, off), "halt")]

    # ---- failure sinks ----------------------------------------------------------
    for i, name in ((1, "fail1"), (2, "fail2"), (3, "fail3")):
        P += [("label", name)]
        P += [LUIi(2, 0xBAD00)]                       # 0xBAD00000
        P += [ADDI(2, 2, i)]
        P += [SW(2, 0, RESULT + 0x00)]
        P += [("label", f"halt{i}"), (lambda off: JAL(0, off), f"halt{i}")]
    return assemble(P)

if __name__ == "__main__":
    for w in prog():
        print(f"{w & 0xFFFFFFFF:08x}")

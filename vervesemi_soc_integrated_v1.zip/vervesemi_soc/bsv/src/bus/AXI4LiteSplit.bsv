// ============================================================================
// AXI4LiteSplit.bsv -- 1 master -> 2 masters address splitter (NEW, integration)
// ----------------------------------------------------------------------------
// Sits on the core's dmem AXI4-Lite master. Transactions whose address is in
// the MMIO window (0x4000_0000 - 0x4FFF_FFFF, i.e. addr[31:28] == 4'h4) are
// steered to the `hi` master (exported off-chip toward the NoC + peripherals);
// everything else goes to `lo` (the internal xbar -> BRAM).
//
// Response ordering: route tags are queued per transaction (rdRoute/wrRoute),
// so R and B responses are returned to the CPU in issue order even if the two
// destinations answer with different latency. W beats follow their AW routing
// decision through wRoute.
// ============================================================================
package AXI4LiteSplit;

import Types    :: *;
import AXI4Lite :: *;
import GetPut   :: *;
import FIFOF    :: *;

interface AXI4LiteSplitIfc;
  interface AXI4Lite_Master lo;   // internal memory side
  interface AXI4Lite_Master hi;   // external MMIO side (NoC window)
endinterface

function Bool isMMIO(Addr a) = (a[31:28] == 4'h4);

module mkAXI4LiteSplit#(AXI4Lite_Master up)(AXI4LiteSplitIfc);

  // ---- request FIFOs toward each destination ----
  FIFOF#(AxiAW) loAW <- mkFIFOF;  FIFOF#(AxiAW) hiAW <- mkFIFOF;
  FIFOF#(AxiW)  loW  <- mkFIFOF;  FIFOF#(AxiW)  hiW  <- mkFIFOF;
  FIFOF#(AxiAR) loAR <- mkFIFOF;  FIFOF#(AxiAR) hiAR <- mkFIFOF;

  // ---- response FIFOs coming back from each destination ----
  FIFOF#(AxiB)  loB  <- mkFIFOF;  FIFOF#(AxiB)  hiB  <- mkFIFOF;
  FIFOF#(AxiR)  loR  <- mkFIFOF;  FIFOF#(AxiR)  hiR  <- mkFIFOF;

  // ---- routing tags (True = hi/MMIO) ----
  FIFOF#(Bool) rdRoute <- mkSizedFIFOF(4);  // AR issue order -> R return order
  FIFOF#(Bool) wrRoute <- mkSizedFIFOF(4);  // AW issue order -> B return order
  FIFOF#(Bool) wRoute  <- mkSizedFIFOF(4);  // AW issue order -> W beat steering

  // ---- accept requests from the upstream master ----
  rule take_ar;
    let a <- up.ar.get;
    if (isMMIO(a.araddr)) hiAR.enq(a); else loAR.enq(a);
    rdRoute.enq(isMMIO(a.araddr));
  endrule

  rule take_aw;
    let a <- up.aw.get;
    Bool h = isMMIO(a.awaddr);
    if (h) hiAW.enq(a); else loAW.enq(a);
    wrRoute.enq(h);
    wRoute.enq(h);
  endrule

  // W beat follows the routing decision of its AW (AXI-Lite: 1 beat / write).
  rule take_w;
    let h = wRoute.first;
    let d <- up.w.get;
    if (h) hiW.enq(d); else loW.enq(d);
    wRoute.deq;
  endrule

  // ---- return responses in issue order ----
  rule give_r_lo (!rdRoute.first);
    let d = loR.first; loR.deq; rdRoute.deq; up.r.put(d);
  endrule
  rule give_r_hi (rdRoute.first);
    let d = hiR.first; hiR.deq; rdRoute.deq; up.r.put(d);
  endrule

  rule give_b_lo (!wrRoute.first);
    let d = loB.first; loB.deq; wrRoute.deq; up.b.put(d);
  endrule
  rule give_b_hi (wrRoute.first);
    let d = hiB.first; hiB.deq; wrRoute.deq; up.b.put(d);
  endrule

  // ---- exported master interfaces ----
  interface AXI4Lite_Master lo;
    interface Get aw = toGet(loAW);
    interface Get w  = toGet(loW);
    interface Put b  = toPut(loB);
    interface Get ar = toGet(loAR);
    interface Put r  = toPut(loR);
  endinterface

  interface AXI4Lite_Master hi;
    interface Get aw = toGet(hiAW);
    interface Get w  = toGet(hiW);
    interface Put b  = toPut(hiB);
    interface Get ar = toGet(hiAR);
    interface Put r  = toPut(hiR);
  endinterface

endmodule

endpackage : AXI4LiteSplit

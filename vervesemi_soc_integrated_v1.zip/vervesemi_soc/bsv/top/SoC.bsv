// ============================================================================
// SoC.bsv -- top-level integration. The `-g mkSoC` synthesis boundary.
// ----------------------------------------------------------------------------
// INTEGRATION CHANGE (vs original intern version):
//   The core's dmem master now goes through mkAXI4LiteSplit. Addresses in
//   0x4000_0000-0x4FFF_FFFF are exported on a new external AXI4-Lite master
//   interface `mmio` (toward the star NoC + UART + NVIC + soc_ctrl at the
//   SystemVerilog level, see rtl/integration/soc_top.sv). Everything else
//   still goes to the internal xbar -> BRAM.
//
// Contents (CPU clock domain unless noted):
//   * mkCore          : the RV32IM pipeline (imem + dmem AXI masters)
//   * mkAXI4LiteSplit : dmem address splitter (BRAM vs external MMIO)   [NEW]
//   * mkDebugModule   : debug command engine + its own AXI master
//   * mkAXI4LiteXbar  : 3 masters (imem, dmem.lo, debug) -> 1 BRAM slave
//   * mkBramMem       : unified I+D memory (AXI slave + TB backdoor)
//   * mkDebugCDC      : crosses debug<->cpu; host side runs on the Debug clock
//
// The default clock/reset are the CPU domain. The Debug clock/reset arrive as
// explicit parameters. The debug host methods (enqReq/getResp/...) are exposed
// on the Debug clock so an external (slower) debug transport drives them.
// In soc_top.sv the Debug clock is wired to JTAG TCK.
// ============================================================================
package SoC;

import Types        :: *;
import Config       :: *;
import Core         :: *;
import DebugModule  :: *;
import DebugCDC     :: *;
import BramMem      :: *;
import AXI4Lite     :: *;
import AXI4LiteXbar :: *;
import AXI4LiteSplit:: *;
import Clocks       :: *;
import Vector       :: *;

interface SoCIfc;
  // ---- External MMIO master (CPU domain) -> NoC/peripherals ----  [NEW]
  interface AXI4Lite_Master mmio;

  // ---- Debug host interface (Debug clock domain) ----
  interface DbgHostIfc debug;

  // ---- Testbench backdoor to memory (CPU domain) ----
  method Action initWord(Bit#(32) wordIdx, Word v);
  method Word   peekWord(Bit#(32) wordIdx);

  // ---- Retire monitor for the scoreboard ----
  method Bool   retired;
endinterface

// dClk/dRst : the (slower) Debug clock domain, supplied externally.
// The module's own clock/reset (default) are the CPU domain.
module mkSoC#(Clock dClk, Reset dRst)(SoCIfc);
  Clock cClk <- exposeCurrentClock;   // CPU clock (default)
  Reset cRst <- exposeCurrentReset;

  // ---- Core, debug, memory ----
  CoreIfc        core <- mkCore;
  DebugCDCIfc    cdc  <- mkDebugCDC(dClk, dRst, cClk, cRst);
  DebugModuleIfc dbg  <- mkDebugModule(core, cdc.core);
  BramMemIfc     mem  <- mkBramMem;

  // ---- dmem splitter: BRAM (lo) vs external MMIO window (hi) ----  [NEW]
  AXI4LiteSplitIfc dsplit <- mkAXI4LiteSplit(core.dmem);

  // ---- Interconnect: [imem, dmem.lo, debug] -> BRAM ----
  Vector#(3, AXI4Lite_Master) masters;
  masters[0] = core.imem;
  masters[1] = dsplit.lo;
  masters[2] = dbg.memAxi;
  mkAXI4LiteXbar(masters, mem.slave);

  // ---- External MMIO master (exported) ----                       [NEW]
  interface mmio = dsplit.hi;

  // ---- Debug host interface (Debug clock domain, re-exported directly) ----
  interface debug = cdc.host;

  method Action initWord(Bit#(32) i, Word v) = mem.initWord(i, v);
  method Word   peekWord(Bit#(32) i) = mem.peekWord(i);
  method Bool   retired = core.retired;
endmodule

endpackage : SoC

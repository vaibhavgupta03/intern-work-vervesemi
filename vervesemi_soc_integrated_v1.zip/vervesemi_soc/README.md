# Integrated SoC — RV32IM (Bluespec) + Star NoC + NVIC + UART + JTAG Debug

Integration of the five intern IP blocks from `intern-work-vervesemi` into one
system-on-chip, with an example firmware, a full-SoC testbench, and two
self-checking smoke tests.

```
                          soc_top.sv
 ┌──────────────────────────────────────────────────────────────────────┐
 │  ┌────────────────── mkSoC (Bluespec, monish) ─────────────────┐     │
 │  │  RV32IM core ──imem──────────────► 3:1 xbar ──► BRAM 64 KiB │     │
 │  │       └──dmem──► AXI4LiteSplit ──lo──┘  ▲       (0x0000_0000)│     │
 │  │  DebugModule ◄─ DebugCDC          hi   │(debug AXI master)  │     │
 │  └────────▲──────────(tck domain)─────│───┴──────────────────── ┘    │
 │           │                           ▼ mmio  (0x4xxx_xxxx)          │
 │   jtag_dm_bridge                 bsc_axi_shim (EN/RDY → AXI4-Lite)   │
 │           ▲                           ▼ M0        M1 = spare          │
 │      dtm_dmi_rv               star-hub NoC (astik)                    │
 │           ▲                    C0        C1..C3                       │
 │       jtag_tap             ┌───┼───┬───────┬─────┐  12 × scratch      │
 │  (ankit, tck/tms/tdi/tdo)  ▼   ▼   ▼       ▼     ▼                    │
 │                          UART NVIC soc_ctrl scratch  (axil_periph_reg)│
 │                        (vaibhav)(vaibhav+bridge)(new)                 │
 └──────────────────────────────────────────────────────────────────────┘
```

## CPU address map

| range                     | block                                            |
|---------------------------|--------------------------------------------------|
| `0x0000_0000-0x0000_FFFF` | BRAM, instructions + data (inside mkSoC)         |
| `0x4000_0000-0x4000_0FFF` | NoC window: `[11:10]`=concentrator, `[9:8]`=peripheral, `[7:0]`=offset |
| `0x4000_0000`             | **UART** (16550-style, 16-bit regs at even offsets) |
| `0x4000_0100`             | **NVIC** (enable/pend/prio; +0x30 CLAIM, +0x34 COMPLETE, +0x38 IRQSTAT) |
| `0x4000_0200`             | **SOC_CTRL** (0x00 SOC_ID, 0x04 RX_DATA, 0x08 RX_COUNT, 0x0C SWIRQ, 0x10 IRQSTAT) |
| `0x4000_0300` + C1–C3     | scratch register peripherals (ID `0xA5A5_00cp`)  |

NVIC `irq_in`: `[15:0]` = `ext_irq` pins, `[16]` = UART rx-valid, `[17]` = UART
tx-done, `[31:24]` = SOC_CTRL software triggers.

## What was changed / added (originals untouched)

| file | status |
|------|--------|
| `bsv/src/bus/AXI4LiteSplit.bsv` | **NEW** — dmem address splitter, exports the `0x4xxx_xxxx` window as an external AXI4-Lite master |
| `bsv/top/SoC.bsv` | **MODIFIED** — instantiates the splitter, adds `mmio` to `SoCIfc` |
| `rtl/integration/soc_top.sv` | **NEW** — top level wiring everything (diagram above) |
| `rtl/integration/bsc_axi_shim.sv` | **NEW** — bsc Get/Put EN-RDY ports → standard AXI4-Lite |
| `rtl/integration/axil_nvic_bridge.v` | **NEW** — AXI4-Lite slave for nvic_top + CLAIM/COMPLETE/IRQSTAT regs |
| `rtl/integration/soc_ctrl.v` | **NEW** — SOC_ID, UART RX mailbox, software IRQ trigger |
| `rtl/integration/uart_top_soc.v` | **DERIVED** from `rtl/uart/uart_top.v`: exposes the dangling `rx_data/rx_valid/tx_busy/tx_done` as ports; TB-only coverage block removed |
| `rtl/integration/dtm_dmi_rv.v` | **DERIVED** from `rtl/debug/dtm_dmi.v`: adds Capture-DR response load so DMI *reads* work over TDO |
| `rtl/integration/jtag_dm_bridge.v` | **NEW** — DMI ↔ Bluespec debug-host protocol bridge (staged 72-bit DbgReq commands) |
| everything under `rtl/noc`, `rtl/uart`, `rtl/nvic`, `rtl/debug`, `bsv/src`, `bsv/verif` | original intern code, unmodified |

Integration quirks handled (worth mentioning in your report):
* the UART AXI slave ignores `wstrb` and only uses `wdata[15:0]`; `soc_top`
  has a byte-lane fixer so CPU `SH`/`LH` to odd halfword offsets work,
* the UART never exposed received bytes on the bus (RBR reads 0) — the RX
  mailbox in `soc_ctrl` fixes that at SoC level,
* the original `dtm_dmi.v` could shift DMI requests in but never responses
  out — `dtm_dmi_rv.v` adds the capture path,
* the DTM registers TDO on posedge TCK, so shifted-out words lag by one bit
  (compensated and documented in both testbenches),
* the baud-rate divider starts at 0, so the free-running 16-bit counter must
  wrap once (65536 cycles) before the first oversample tick — firmware just
  waits this out once at boot,
* the CPU core has no asynchronous-interrupt input (mcause interrupt bit is
  hard-wired 0), so interrupt delivery is by **polling** NVIC `IRQSTAT`
  (0x4000_0138); the `irq_out` pin is exported for a future `mip.meip` hookup.

## Quick start

```
make fw            # regenerate the demo firmware hex
make lint          # slang elaboration of the whole SoC (no bsc needed)
make smoke         # CXXRTL smoke tests (no bsc/verilator needed)
make bsv-verilog   # bsc: generate bsv/verilog/mkSoC.v   } on a machine
make sim           # Verilator: full-SoC end-to-end test  } with bsc+verilator
```

See `docs/VERIFICATION_GUIDE.md` for the step-by-step verification procedure
and `docs/EXAMPLE_FLOW.md` for a cycle-by-cycle walk-through of how one
transaction flows through the whole SoC.

## Verified so far (in the environment this was built in — no bsc available)

* `make lint`: full design + full-SoC TB elaborate with slang, 0 errors / 0 warnings
* `make smoke` test 1: AXI → UART config → TX 'A' → loopback RX → soc_ctrl
  mailbox → NVIC pend/enable/priority/claim/complete — **10/10 checks pass**
* `make smoke` test 2: JTAG TAP → IR=DMI → staged DbgReq(cmd/regno/addr/wdata)
  → response readback over TDO → halted status — **11/11 checks pass**

Still to run on a machine with **bsc + Verilator** (see the guide):
`make bsv-verilog` (checks the BSV changes compile; verify the generated port
names against `bsc_axi_shim.sv`) and `make sim` (full-SoC firmware test +
JTAG halt/resume demo).
